package com.pixelsoft.cetakfoto;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;

public class MainActivity extends Activity {
    private static final int PICK_IMAGES = 101;
    private static final String PIXELSOFT_WA_NUMBER = "6282163917003";
    private static final int MAX_PHOTOS = 10;

    private final ArrayList<Uri> selectedUris = new ArrayList<>();
    private final ArrayList<OrderItem> items = new ArrayList<>();
    private LinearLayout root;
    private LinearLayout listContainer;
    private TextView countText;
    private EditText noteInput;
    private boolean addingPhotos = false;
    private String customerNote = "";

    private final String[] photoSizes = {
            "Pas Foto 2×3", "Pas Foto 3×4", "Pas Foto 4×6", "Dompet",
            "3R (biasa)", "4R (Jumbo Kecil)", "5R (Jumbo Besar)",
            "8R (10 inch)", "Full A4"
    };
    private final String[] printTypes = {"Cetak Foto", "Gambar di HVS"};
    private final String[] hvsPapers = {"HVS A4", "HVS F4"};
    private final String[] hvsColors = {"Warna", "Hitam Putih"};
    private final String[] hvsLayouts = {"1 gambar / lembar", "2 gambar / lembar", "3 gambar / lembar", "4 gambar / lembar", "5 gambar / lembar", "6 gambar / lembar"};

    static class OrderItem {
        Uri uri;
        String printType = "Cetak Foto";
        String size = "Pas Foto 4×6";
        String paper = "HVS A4";
        String colorMode = "Warna";
        String layout = "1 gambar / lembar";
        int qty = 1;
        boolean fit = true;
        String background = "Tidak diganti";
        OrderItem(Uri uri) { this.uri = uri; }
    }

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        showHome();
    }

    private int dp(float v) {
        return (int)(v * getResources().getDisplayMetrics().density + .5f);
    }

    private TextView text(String s, float sp) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(Color.rgb(22,50,71));
        t.setPadding(dp(6), dp(5), dp(6), dp(5));
        return t;
    }

    private TextView label(String s) {
        TextView t = text(s, 13);
        t.setTextColor(Color.rgb(107,124,136));
        return t;
    }

    private Button button(String s, boolean primary) {
        Button b = new Button(this);
        b.setText(s);
        b.setTextSize(15);
        b.setAllCaps(false);
        b.setMinHeight(dp(50));
        b.setPadding(dp(12), dp(4), dp(12), dp(4));
        b.setTextColor(primary ? Color.WHITE : Color.rgb(22,50,71));
        b.setBackgroundResource(primary ? R.drawable.drawable_primary_button : R.drawable.drawable_secondary_button);
        return b;
    }

    private void base(String title) {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(245,248,250));
        if (android.os.Build.VERSION.SDK_INT >= 30) {
            getWindow().setDecorFitsSystemWindows(true);
        }
        getWindow().setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);

        root.setOnApplyWindowInsetsListener((v, insets) -> {
            android.graphics.Insets bars = insets.getInsets(
                    WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars());
            int imeBottom = 0;
            if (android.os.Build.VERSION.SDK_INT >= 23) {
                imeBottom = insets.getInsets(WindowInsets.Type.ime()).bottom;
            }
            v.setPadding(0, bars.top, 0, Math.max(bars.bottom, imeBottom));
            return insets;
        });

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.VERTICAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(20), dp(8), dp(20), dp(8));
        bar.setBackgroundColor(Color.rgb(12,145,181));
        ImageView brandLogo = new ImageView(this);
        brandLogo.setImageResource(R.drawable.pixelsoft_logo);
        brandLogo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        bar.addView(brandLogo, new LinearLayout.LayoutParams(-1, dp(46)));
        root.addView(bar, new LinearLayout.LayoutParams(-1, dp(64)));

        setContentView(root);
        root.requestApplyInsets();
    }

    private void addSpace(LinearLayout box, int h) {
        SpaceView space = new SpaceView();
        box.addView(space, new LinearLayout.LayoutParams(1, dp(h)));
    }

    private class SpaceView extends View { SpaceView() { super(MainActivity.this); } }

    private void showHome() {
        base("Layanan PixelSoft");
        ScrollView scroll = new ScrollView(this);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER_HORIZONTAL);
        box.setPadding(dp(22), dp(22), dp(22), dp(20));

        TextView welcome = text("Cetak Foto & Gambar", 27);
        welcome.setGravity(Gravity.CENTER);
        welcome.setTypeface(null, android.graphics.Typeface.BOLD);
        welcome.setTextColor(Color.rgb(18,91,135));
        box.addView(welcome, new LinearLayout.LayoutParams(-1, -2));

        TextView sub = text("Cara Mudah Cetak Foto di PixelSoft", 15);
        sub.setGravity(Gravity.CENTER);
        sub.setTextColor(Color.rgb(76,99,112));
        box.addView(sub, new LinearLayout.LayoutParams(-1, -2));

        TextView flow = text("Pilih foto  →  Atur kebutuhan  →  Kirim pesanan", 13);
        flow.setGravity(Gravity.CENTER);
        flow.setTextColor(Color.rgb(107,124,136));
        flow.setPadding(dp(4), dp(10), dp(4), dp(10));
        box.addView(flow, new LinearLayout.LayoutParams(-1, -2));

        ImageView icon = new ImageView(this);
        icon.setImageResource(R.drawable.pixelsoft_icon);
        icon.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(-1, dp(230));
        ip.topMargin = dp(2);
        box.addView(icon, ip);

        Button pick = button("📷  Pilih Foto / Gambar", true);
        pick.setTextSize(16);
        box.addView(pick, new LinearLayout.LayoutParams(-1, dp(56)));
        pick.setOnClickListener(v -> pickImages());

        TextView info = text("Maksimal 10 foto per pesanan", 13);
        info.setGravity(Gravity.CENTER);
        info.setTextColor(Color.rgb(107,124,136));
        box.addView(info, new LinearLayout.LayoutParams(-1, dp(34)));

        Button help = button("ⓘ  Cara menggunakan   ›", false);
        help.setGravity(Gravity.CENTER_VERTICAL | Gravity.LEFT);
        box.addView(help, new LinearLayout.LayoutParams(-1, dp(50)));
        help.setOnClickListener(v -> showHowToUse());

        scroll.addView(box);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        TextView foot = text("PixelSoft • Solusi Cetak & Layanan Digital", 12);
        foot.setGravity(Gravity.CENTER);
        foot.setTextColor(Color.rgb(107,124,136));
        root.addView(foot, new LinearLayout.LayoutParams(-1, dp(38)));
    }

    private void showHowToUse() {
        final android.app.Dialog d = new android.app.Dialog(this);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(18), dp(20), dp(16));
        TextView title = text("Cara menggunakan PixelSoft", 19);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        box.addView(title);
        TextView body = text("1. Pilih foto atau gambar dari galeri HP Anda.\n\n2. Atur ukuran, jumlah, dan kebutuhan cetak.\n\n3. Periksa ringkasan pesanan.\n\n4. Kirim pesanan ke WhatsApp PixelSoft.\n\n💡 Untuk tugas sekolah, pilih Gambar di HVS.", 14);
        box.addView(body, new LinearLayout.LayoutParams(-1, -2));
        Button ok = button("Mengerti", true);
        ok.setOnClickListener(v -> d.dismiss());
        LinearLayout.LayoutParams op = new LinearLayout.LayoutParams(-1, dp(50));
        op.topMargin = dp(10);
        box.addView(ok, op);
        d.setContentView(box);
        android.view.Window w = d.getWindow();
        if (w != null) w.setBackgroundDrawableResource(android.R.color.white);
        d.show();
    }

    private void pickImages() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.setType("image/*");
        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(i, PICK_IMAGES);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != PICK_IMAGES || resultCode != RESULT_OK || data == null) {
            addingPhotos = false;
            return;
        }

        ArrayList<Uri> picked = new ArrayList<>();
        if (data.getClipData() != null) {
            int n = data.getClipData().getItemCount();
            for (int x = 0; x < n; x++) picked.add(data.getClipData().getItemAt(x).getUri());
        } else if (data.getData() != null) {
            picked.add(data.getData());
        }
        if (picked.isEmpty()) { addingPhotos = false; return; }

        int added = 0;
        if (addingPhotos && !items.isEmpty()) {
            for (Uri u : picked) {
                if (items.size() >= MAX_PHOTOS) break;
                if (selectedUris.contains(u)) continue;
                selectedUris.add(u);
                items.add(new OrderItem(u));
                added++;
            }
            if (picked.size() > added) {
                Toast.makeText(this, "Sebagian foto tidak ditambahkan. Maksimal 10 foto dan foto duplikat dilewati.", Toast.LENGTH_LONG).show();
            }
        } else {
            selectedUris.clear();
            items.clear();
            for (Uri u : picked) {
                if (items.size() >= MAX_PHOTOS) break;
                if (selectedUris.contains(u)) continue;
                selectedUris.add(u);
                items.add(new OrderItem(u));
            }
            if (picked.size() > items.size()) {
                Toast.makeText(this, "Maksimal 10 foto. Foto duplikat tidak ditambahkan.", Toast.LENGTH_LONG).show();
            }
        }

        addingPhotos = false;
        if (!items.isEmpty()) showEditor();
    }

    private void showEditor() {
        base("Atur Pesanan");
        ScrollView scroll = new ScrollView(this);
        listContainer = new LinearLayout(this);
        listContainer.setOrientation(LinearLayout.VERTICAL);
        listContainer.setPadding(dp(12), dp(12), dp(12), dp(20));

        LinearLayout head = new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = text("Foto pesanan", 22);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        head.addView(title, new LinearLayout.LayoutParams(0, -2, 1));
        countText = text(items.size() + " / " + MAX_PHOTOS + " foto", 14);
        countText.setGravity(Gravity.CENTER);
        countText.setTextColor(Color.rgb(12,145,181));
        countText.setBackgroundResource(R.drawable.drawable_pill);
        head.addView(countText, new LinearLayout.LayoutParams(dp(105), dp(38)));
        listContainer.addView(head);

        TextView helper = label("Atur ukuran dan jumlah untuk setiap foto.");
        listContainer.addView(helper);

        for (int i = 0; i < items.size(); i++) addItemView(i);

        Button add = button("＋  Tambah Foto", false);
        add.setOnClickListener(v -> {
            if (items.size() >= MAX_PHOTOS) {
                Toast.makeText(this, "Sudah mencapai maksimal 10 foto.", Toast.LENGTH_SHORT).show();
                return;
            }
            addingPhotos = true;
            pickImages();
        });
        listContainer.addView(add, new LinearLayout.LayoutParams(-1, dp(50)));

        addSpace(listContainer, 8);
        TextView noteLabel = text("Catatan untuk PixelSoft (opsional)", 16);
        noteLabel.setTypeface(null, android.graphics.Typeface.BOLD);
        listContainer.addView(noteLabel);
        noteInput = new EditText(this);
        noteInput.setHint("Contoh: Tolong cetak sore, akan saya ambil langsung.");
        noteInput.setText(customerNote);
        noteInput.setTextSize(14);
        noteInput.setGravity(Gravity.TOP | Gravity.START);
        noteInput.setMinLines(3);
        noteInput.setPadding(dp(12), dp(10), dp(12), dp(10));
        noteInput.setOnFocusChangeListener((v, hasFocus) -> {
            if (hasFocus) {
                v.postDelayed(() -> scroll.smoothScrollTo(0, Math.max(0, v.getBottom() - dp(80))), 180);
            }
        });
        listContainer.addView(noteInput, new LinearLayout.LayoutParams(-1, dp(90)));

        addSpace(listContainer, 10);
        Button next = button("Lanjut ke Ringkasan  →", true);
        next.setOnClickListener(v -> {
            saveNote();
            showSummary();
        });
        listContainer.addView(next, new LinearLayout.LayoutParams(-1, dp(54)));

        scroll.addView(listContainer);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
    }

    private void addItemView(int index) {
        OrderItem item = items.get(index);
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(12), dp(10), dp(12), dp(12));
        card.setBackgroundResource(R.drawable.drawable_card);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, -2);
        cp.bottomMargin = dp(10);
        listContainer.addView(card, cp);

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        ImageView iv = new ImageView(this);
        iv.setImageURI(item.uri);
        iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
        top.addView(iv, new LinearLayout.LayoutParams(dp(92), dp(92)));

        LinearLayout nameBox = new LinearLayout(this);
        nameBox.setOrientation(LinearLayout.VERTICAL);
        nameBox.setPadding(dp(12), 0, dp(4), 0);
        TextView name = text("Foto " + (index + 1), 18);
        name.setTypeface(null, android.graphics.Typeface.BOLD);
        nameBox.addView(name);
        TextView hint = label("Atur kebutuhan cetak di bawah");
        nameBox.addView(hint);
        top.addView(nameBox, new LinearLayout.LayoutParams(0, -2, 1));

        Button remove = button("🗑 Hapus", false);
        remove.setTextSize(12);
        remove.setTextColor(Color.rgb(190,65,45));
        remove.setBackgroundResource(R.drawable.drawable_danger_button);
        remove.setOnClickListener(v -> {
            selectedUris.remove(item.uri);
            items.remove(item);
            if (items.isEmpty()) showHome(); else showEditor();
            Toast.makeText(this, "Foto dihapus dari pesanan.", Toast.LENGTH_SHORT).show();
        });
        top.addView(remove, new LinearLayout.LayoutParams(dp(76), dp(42)));
        card.addView(top);

        addSpace(card, 6);
        TextView typeLabel = label("Jenis cetak");
        card.addView(typeLabel);
        LinearLayout typeRow = new LinearLayout(this);
        typeRow.setGravity(Gravity.CENTER_VERTICAL);
        Button photoType = button("📷\nCetak Foto", false);
        photoType.setTextSize(12);
        Button hvsType = button("📄\nGambar di HVS", false);
        hvsType.setTextSize(12);
        typeRow.addView(photoType, new LinearLayout.LayoutParams(0, dp(62), 1));
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(0, dp(62), 1);
        hp.leftMargin = dp(8);
        typeRow.addView(hvsType, hp);
        card.addView(typeRow);
        View.OnClickListener typeClick = v -> {
            item.printType = (v == photoType) ? "Cetak Foto" : "Gambar di HVS";
            showEditor();
        };
        photoType.setOnClickListener(typeClick);
        hvsType.setOnClickListener(typeClick);
        styleTypeButton(photoType, item.printType.equals("Cetak Foto"));
        styleTypeButton(hvsType, item.printType.equals("Gambar di HVS"));

        LinearLayout row = new LinearLayout(this);
        row.setTag("photoSizeRow");
        row.setGravity(Gravity.CENTER_VERTICAL);
        TextView sl = label("Ukuran");
        row.addView(sl, new LinearLayout.LayoutParams(dp(52), dp(50)));
        Spinner sp = new Spinner(this);
        ArrayAdapter<String> ad = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, photoSizes);
        sp.setAdapter(ad);
        sp.setSelection(indexOf(photoSizes, item.size));
        sp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onNothingSelected(AdapterView<?> p) {}
            public void onItemSelected(AdapterView<?> p, View v, int pos, long id) {
                item.size = photoSizes[pos];
                updateOptions(card, item);
            }
        });
        row.addView(sp, new LinearLayout.LayoutParams(0, dp(50), 1));
        TextView ql = label("Jumlah");
        ql.setGravity(Gravity.CENTER_VERTICAL);
        row.addView(ql, new LinearLayout.LayoutParams(dp(52), dp(50)));
        EditText qty = new EditText(this);
        qty.setInputType(2);
        qty.setText(String.valueOf(item.qty));
        qty.setSelectAllOnFocus(true);
        qty.setGravity(Gravity.CENTER);
        qty.setOnFocusChangeListener((v, has) -> {
            if (!has) {
                try {
                    int q = Integer.parseInt(qty.getText().toString().trim());
                    item.qty = Math.min(99, Math.max(1, q));
                } catch (Exception e) { item.qty = 1; }
                qty.setText(String.valueOf(item.qty));
            }
        });
        row.addView(qty, new LinearLayout.LayoutParams(dp(55), dp(50)));
        card.addView(row);

        updateOptions(card, item);
    }

    private void styleTypeButton(Button b, boolean active) {
        b.setTextColor(active ? Color.WHITE : Color.rgb(22,50,71));
        b.setBackgroundResource(active ? R.drawable.drawable_primary_button : R.drawable.drawable_secondary_button);
    }

    private boolean isPasFoto(String size) { return size.startsWith("Pas Foto"); }

    private void updateOptions(LinearLayout card, OrderItem item) {
        View sizeRow = card.findViewWithTag("photoSizeRow");
        if (sizeRow != null) sizeRow.setVisibility(item.printType.equals("Cetak Foto") ? View.VISIBLE : View.GONE);

        View old = card.findViewWithTag("printOptions");
        if (old instanceof ViewGroup) ((ViewGroup) old.getParent()).removeView(old);

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setTag("printOptions");
        card.addView(box);

        if (item.printType.equals("Cetak Foto")) {
            CheckBox fit = new CheckBox(this);
            fit.setText("Sesuaikan foto dengan ukuran (crop bila perlu)");
            fit.setTextSize(13);
            fit.setChecked(item.fit);
            fit.setOnCheckedChangeListener((b,c) -> item.fit = c);
            box.addView(fit);

            if (isPasFoto(item.size)) {
                TextView pl = text("Pengaturan Pas Foto", 14);
                pl.setTextColor(Color.rgb(12,145,181));
                pl.setTypeface(null, android.graphics.Typeface.BOLD);
                box.addView(pl);

                CheckBox replace = new CheckBox(this);
                replace.setText("Ganti latar foto");
                replace.setTextSize(13);
                replace.setChecked(!item.background.equals("Tidak diganti"));
                box.addView(replace);

                Spinner bg = new Spinner(this);
                String[] backgrounds = {"Tidak diganti", "Merah", "Biru"};
                ArrayAdapter<String> bgAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, backgrounds);
                bg.setAdapter(bgAdapter);
                bg.setSelection(indexOf(backgrounds, item.background));
                bg.setEnabled(replace.isChecked());
                bg.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                    public void onNothingSelected(AdapterView<?> p) {}
                    public void onItemSelected(AdapterView<?> p, View v, int pos, long id) { item.background = backgrounds[pos]; }
                });
                replace.setOnCheckedChangeListener((b, checked) -> {
                    bg.setEnabled(checked);
                    if (!checked) { item.background = "Tidak diganti"; bg.setSelection(0); }
                    else if (item.background.equals("Tidak diganti")) { item.background = "Merah"; bg.setSelection(1); }
                });
                box.addView(bg, new LinearLayout.LayoutParams(dp(155), dp(50)));
            }
        } else {
            TextView hl = text("Pengaturan HVS", 14);
            hl.setTextColor(Color.rgb(12,145,181));
            hl.setTypeface(null, android.graphics.Typeface.BOLD);
            box.addView(hl);

            addChoice(box, "Kertas", hvsPapers, item.paper, value -> item.paper = value);
            addChoice(box, "Cetak", hvsColors, item.colorMode, value -> item.colorMode = value);
            TextView layoutLabel = label("Gambar per lembar");
            box.addView(layoutLabel);
            LinearLayout layoutRow = new LinearLayout(this);
            layoutRow.setOrientation(LinearLayout.HORIZONTAL);
            layoutRow.setGravity(Gravity.CENTER_VERTICAL);
            for (int i = 0; i < hvsLayouts.length; i++) {
                final String value = hvsLayouts[i];
                Button b = button(String.valueOf(i + 1), false);
                b.setTextSize(14);
                styleLayoutButton(b, item.layout.equals(value));
                b.setOnClickListener(v -> { item.layout = value; updateOptions(card, item); });
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(42), 1);
                if (i > 0) lp.leftMargin = dp(5);
                layoutRow.addView(b, lp);
            }
            box.addView(layoutRow);
            TextView hint = label("Cocok untuk tugas sekolah, gambar, materi, dan dokumen bergambar.");
            hint.setTextSize(12);
            box.addView(hint);
        }
    }

    private void styleLayoutButton(Button b, boolean active) {
        b.setTextColor(active ? Color.WHITE : Color.rgb(22,50,71));
        b.setBackgroundResource(active ? R.drawable.drawable_primary_button : R.drawable.drawable_secondary_button);
    }

    private interface StringSetter { void set(String value); }

    private void addChoice(LinearLayout box, String labelText, String[] values, String selected, StringSetter setter) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        TextView l = label(labelText);
        row.addView(l, new LinearLayout.LayoutParams(dp(78), dp(48)));
        Spinner sp = new Spinner(this);
        ArrayAdapter<String> ad = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, values);
        sp.setAdapter(ad);
        sp.setSelection(indexOf(values, selected));
        sp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onNothingSelected(AdapterView<?> p) {}
            public void onItemSelected(AdapterView<?> p, View v, int pos, long id) { setter.set(values[pos]); }
        });
        row.addView(sp, new LinearLayout.LayoutParams(0, dp(48), 1));
        box.addView(row);
    }

    private int indexOf(String[] a, String s) {
        for (int i=0;i<a.length;i++) if (a[i].equals(s)) return i;
        return 0;
    }

    private void saveNote() {
        if (noteInput != null) customerNote = noteInput.getText().toString().trim();
    }

    private void showSummary() {
        saveNote();
        for (OrderItem item : items) item.qty = Math.min(99, Math.max(1, item.qty));
        base("Ringkasan Pesanan");
        ScrollView scroll = new ScrollView(this);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(16), dp(16), dp(16), dp(20));

        TextView title = text("Pesanan Anda", 23);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        box.addView(title);
        TextView sub = label("Periksa kembali sebelum dikirim ke WhatsApp.");
        box.addView(sub);
        addSpace(box, 8);

        int total = 0;
        for (int i=0;i<items.size();i++) {
            OrderItem o = items.get(i);
            total += o.qty;
            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.HORIZONTAL);
            card.setGravity(Gravity.CENTER_VERTICAL);
            card.setPadding(dp(12), dp(8), dp(12), dp(8));
            card.setBackgroundResource(R.drawable.drawable_card);
            ImageView iv = new ImageView(this);
            iv.setImageURI(o.uri);
            iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
            card.addView(iv, new LinearLayout.LayoutParams(dp(58), dp(58)));
            String detail;
            if (o.printType.equals("Gambar di HVS")) {
                detail = "Gambar di HVS\n" + o.paper + " • " + o.colorMode + "\n" + o.layout + " • " + o.qty + " lembar";
            } else {
                detail = o.size + " • " + o.qty + " lembar\n" +
                        (o.fit ? "Sesuaikan/crop" : "Tanpa crop") +
                        (isPasFoto(o.size) ? " • Latar: " + o.background : "");
            }
            TextView t = text("Foto " + (i+1) + "\n" + detail, 14);
            t.setPadding(dp(10), dp(4), dp(4), dp(4));
            card.addView(t, new LinearLayout.LayoutParams(0, -2, 1));
            LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, -2);
            cp.bottomMargin = dp(8);
            box.addView(card, cp);
        }

        TextView totalText = text("TOTAL  •  " + total + " LEMBAR", 20);
        totalText.setTypeface(null, android.graphics.Typeface.BOLD);
        totalText.setTextColor(Color.rgb(12,145,181));
        totalText.setGravity(Gravity.CENTER);
        totalText.setPadding(8, dp(12), 8, dp(12));
        box.addView(totalText);

        if (!customerNote.isEmpty()) {
            TextView nt = text("Catatan\n" + customerNote, 14);
            nt.setBackgroundResource(R.drawable.drawable_card);
            box.addView(nt, new LinearLayout.LayoutParams(-1, -2));
        }

        addSpace(box, 12);
        Button edit = button("←  Kembali Atur Pesanan", false);
        edit.setOnClickListener(v -> showEditor());
        box.addView(edit, new LinearLayout.LayoutParams(-1, dp(50)));
        addSpace(box, 6);
        Button send = button("📲  Kirim Pesanan ke WhatsApp", true);
        send.setTextSize(16);
        send.setOnClickListener(v -> sendToWhatsApp());
        box.addView(send, new LinearLayout.LayoutParams(-1, dp(56)));

        TextView note = label("Foto akan dilampirkan ke WhatsApp bersama detail pesanan.");
        note.setGravity(Gravity.CENTER);
        box.addView(note, new LinearLayout.LayoutParams(-1, dp(46)));

        scroll.addView(box);
        root.addView(scroll, new LinearLayout.LayoutParams(-1,0,1));
    }

    private void sendToWhatsApp() {
        StringBuilder msg = new StringBuilder("Halo PixelSoft, saya ingin memesan cetak foto/gambar.\n\n");
        int total = 0;
        for (int i=0;i<items.size();i++) {
            OrderItem o = items.get(i);
            total += o.qty;
            msg.append(i+1).append(". Foto ").append(i+1).append(" — ");
            if (o.printType.equals("Gambar di HVS")) {
                msg.append("Gambar di HVS — ").append(o.paper)
                        .append(" — ").append(o.colorMode)
                        .append(" — ").append(o.layout)
                        .append(" — ").append(o.qty).append(" lembar");
            } else {
                msg.append(o.size).append(" — ").append(o.qty).append(" lembar — ")
                        .append(o.fit ? "sesuaikan/crop" : "tanpa crop");
                if (isPasFoto(o.size)) msg.append(" — latar: ").append(o.background);
            }
            msg.append("\n");
        }
        msg.append("\nTotal: ").append(total).append(" lembar");
        if (!customerNote.isEmpty()) msg.append("\n\nCatatan: ").append(customerNote);

        ArrayList<Uri> uris = new ArrayList<>();
        for (OrderItem o : items) uris.add(o.uri);
        Intent share = new Intent(Intent.ACTION_SEND_MULTIPLE);
        share.setType("image/*");
        share.putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris);
        share.putExtra(Intent.EXTRA_TEXT, msg.toString());
        share.putExtra("jid", PIXELSOFT_WA_NUMBER + "@s.whatsapp.net");
        share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        share.setPackage("com.whatsapp");
        try {
            startActivity(share);
        } catch (Exception e) {
            Toast.makeText(this, "WhatsApp belum terpasang atau tidak bisa dibuka.", Toast.LENGTH_LONG).show();
            Intent fallback = new Intent(Intent.ACTION_VIEW,
                    Uri.parse("https://wa.me/" + PIXELSOFT_WA_NUMBER + "?text=" + Uri.encode(msg.toString())));
            startActivity(fallback);
        }
    }
}
