# PixelSoft Cetak Foto v1.11.0

Penambahan fitur **Susun Foto ke Media Cetak**.

- Terintegrasi ke layanan Cetak Foto & Gambar.
- Pelanggan dapat memilih ukuran 2×3 cm, 3×4 cm, atau 4×6 cm.
- Foto dapat digeser pada media layout.
- Foto yang sama boleh ditambahkan berkali-kali, termasuk dengan ukuran berbeda.
- Hasil akhir dibuat sebagai satu JPG 1200×1800 px (media layout internal 4×6 inch pada 300 dpi).
- File dikirim langsung ke WhatsApp PixelSoft menggunakan target JID yang sama dengan modul sebelumnya.
- Tidak ada editing/background replacement pada fitur ini; foto ditempatkan apa adanya dengan proporsi dipertahankan.
