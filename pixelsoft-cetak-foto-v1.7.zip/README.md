# PixelSoft Cetak Foto v1.1

Aplikasi pemesanan cetak foto PixelSoft.

## WhatsApp PixelSoft
082163917003

## Ukuran Cetak
- Pas Foto 2×3
- Pas Foto 3×4
- Pas Foto 4×6
- Dompet
- 3R (biasa)
- 4R (Jumbo Kecil)
- 5R (Jumbo Besar)
- 8R (10 inch)
- Full A4

Untuk ukuran Pas Foto, tersedia pilihan **Ganti latar**: Tidak diganti, Merah, atau Biru.


## v1.2 changes
- Tambah Foto sekarang menambahkan foto baru ke pesanan, bukan mengganti foto yang sudah ada.
- Pesan WhatsApp tidak lagi mencantumkan nomor WhatsApp PixelSoft.
- Pengiriman WhatsApp mencoba menargetkan chat PixelSoft menggunakan JID WhatsApp sambil tetap membawa foto dan detail pesanan.
- Jika versi WhatsApp tertentu tidak menerima JID pada intent berbagi gambar, Android/WhatsApp dapat kembali menampilkan pemilih kontak. Ini adalah keterbatasan integrasi intent, bukan bug pada daftar foto.


## v1.4
- Eksperimen pengiriman sekali ke WhatsApp dengan caption berbeda pada setiap lampiran menggunakan ClipData per foto.
- Menghapus caption global EXTRA_TEXT agar keterangan tidak diulang pada semua foto.
- Tetap mempertahankan target chat PixelSoft dengan JID.


## v1.6
- UI diperbarui dengan kartu foto dan tombol yang lebih rapi.
- Tambah Foto mempertahankan foto lama, melewati duplikat, dan membatasi 10 foto.
- Hapus foto per item.
- Validasi jumlah cetak 1–99 lembar.
- Tambahan kolom Catatan untuk PixelSoft.
- Ringkasan menampilkan thumbnail dan detail pesanan.
- Pengiriman WhatsApp tetap menggunakan satu kali kirim dengan detail pesanan global yang sebelumnya sudah terbukti bekerja.


## v1.6 Keyboard Fix
- Keyboard uses adjustResize and IME insets.
- Catatan untuk PixelSoft automatically scrolls into view when focused.


## v1.7
- Nama layanan diperbarui menjadi PixelSoft.
- Cetak Foto dikembangkan menjadi Cetak Foto & Gambar.
- Setiap foto dapat dipilih sebagai Cetak Foto atau Gambar di HVS.
- Mode HVS menyediakan pilihan kertas A4/F4, warna/Hitam Putih, dan tata letak 1/2/4 gambar per lembar.
- Detail HVS ikut masuk ke ringkasan dan pesan WhatsApp.
- Fitur v1.6 dan perbaikan keyboard tetap dipertahankan.
