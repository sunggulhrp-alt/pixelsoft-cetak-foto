PixelSoft v1.12.9

Basis: v1.12.5 (layout editor logic preserved).

Update:
- Pasfoto actual sizes remain 2.15x2.8 cm, 2.85x3.75 cm, 3.8x5.7 cm.
- Adds a 1.2 mm white cutting margin on every side.
- The movable/selectable frame is actual photo + 1.2 mm margin per side.
- The photo itself remains inside the actual photo area; margin is white and does not replace the photo area.
- 90 degree rotation applies to the complete pasfoto frame.
- Frame cannot be moved outside the 4x6 inch media.
- Export remains 1200x1800 px at 300 DPI.
