# PixelSoft Cetak Foto v1

Aplikasi Android sederhana untuk pelanggan PixelSoft:

1. Pilih sampai 10 foto dari galeri.
2. Atur ukuran cetak dan jumlah lembar untuk setiap foto.
3. Pilih mode sesuaikan/crop atau utuh sebagai instruksi pesanan.
4. Lihat ringkasan pesanan.
5. Bagikan foto dan detail pesanan ke WhatsApp.

## Penting sebelum build

Buka `app/src/main/java/com/pixelsoft/cetakfoto/MainActivity.java` lalu ganti:

`628XXXXXXXXXX`

menjadi nomor WhatsApp PixelSoft dalam format internasional tanpa tanda `+` atau spasi.

Contoh: `6281234567890`

## Build di GitHub

Workflow `.github/workflows/build-apk.yml` akan membuat APK debug pada setiap push ke `main` atau saat dijalankan manual. APK tersedia di **Actions → workflow run → Artifacts**.

## Catatan WhatsApp

Android/WhatsApp dapat menampilkan pemilih kontak ketika aplikasi membagikan banyak foto. Versi v1 menggunakan mekanisme share resmi Android, bukan API WhatsApp Business, sehingga tidak memerlukan server.
