package com.pixelsoft.cetakfoto;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.DatePicker;
import android.app.DatePickerDialog;
import android.widget.Toast;
import android.widget.Space;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.text.Editable;
import android.text.TextWatcher;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Calendar;
import java.io.File;
import android.content.ActivityNotFoundException;
import android.content.ClipData;

public class MainActivity extends Activity {
    private static final int PICK_IMAGES = 101;
    private static final String PIXELSOFT_WA_NUMBER = "6282163917003";
    private static final int MAX_PHOTOS = 10;
    private static final int PICK_LAYOUT_IMAGE = 102;
    private final ArrayList<LayoutPhoto> layoutPhotos = new ArrayList<>();
    private LayoutCanvas layoutCanvas;

    private final ArrayList<Uri> selectedUris = new ArrayList<>();
    private final ArrayList<OrderItem> items = new ArrayList<>();
    private LinearLayout root;
    private LinearLayout listContainer;
    private TextView countText;
    private EditText noteInput;
    private boolean addingPhotos = false;
    private String customerNote = "";
    private boolean homeScreen = true;

    // Pengetikan - Surat Jual Beli
    private final Map<String, EditText> suratFields = new LinkedHashMap<>();
    private String suratTanggal = "";

    private final String[] photoSizes = {
            "Pas Foto 2×3", "Pas Foto 3×4", "Pas Foto 4×6", "Dompet",
            "3R (biasa)", "4R (Jumbo Kecil)", "5R (Jumbo Besar)",
            "8R (10 inch)", "Full A4"
    };
    private final String[] printTypes = {"Cetak Foto", "Gambar di HVS"};
    private final String[] hvsPapers = {"HVS A4", "HVS F4"};
    private final String[] hvsColors = {"Warna", "Hitam Putih"};
    private final String[] hvsLayouts = {"1 gambar / lembar", "2 gambar / lembar", "3 gambar / lembar", "4 gambar / lembar", "5 gambar / lembar", "6 gambar / lembar"};

    static class LayoutPhoto {
        Uri uri;
        String size = "3×4 cm";
        Bitmap bitmap;
        float x, y;
        LayoutPhoto(Uri uri) { this.uri = uri; }
    }

    static class OrderItem {
        Uri uri;
        String printType = "Cetak Foto";
        String size = "Pas Foto 4×6";
        String paper = "HVS A4";
        String colorMode = "Warna";
        String layout = "1 gambar / lembar";
        int qty = 1;
        boolean fit = true;
        String background = "Tidak diganti";
        OrderItem(Uri uri) { this.uri = uri; }
    }

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        showHome();
    }

    private int dp(float v) {
        return (int)(v * getResources().getDisplayMetrics().density + .5f);
    }

    private TextView text(String s, float sp) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(Color.rgb(22,50,71));
        t.setPadding(dp(6), dp(5), dp(6), dp(5));
        return t;
    }

    private TextView label(String s) {
        TextView t = text(s, 13);
        t.setTextColor(Color.rgb(107,124,136));
        return t;
    }

    private Button button(String s, boolean primary) {
        Button b = new Button(this);
        b.setText(s);
        b.setTextSize(15);
        b.setAllCaps(false);
        b.setMinHeight(dp(50));
        b.setPadding(dp(12), dp(4), dp(12), dp(4));
        b.setTextColor(primary ? Color.WHITE : Color.rgb(22,50,71));
        b.setBackgroundResource(primary ? R.drawable.drawable_primary_button : R.drawable.drawable_secondary_button);
        return b;
    }

    private void base(String title) {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(245,248,250));
        if (android.os.Build.VERSION.SDK_INT >= 30) {
            getWindow().setDecorFitsSystemWindows(true);
        }
        getWindow().setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);

        root.setOnApplyWindowInsetsListener((v, insets) -> {
            android.graphics.Insets bars = insets.getInsets(
                    WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars());
            int imeBottom = 0;
            if (android.os.Build.VERSION.SDK_INT >= 23) {
                imeBottom = insets.getInsets(WindowInsets.Type.ime()).bottom;
            }
            v.setPadding(0, bars.top, 0, Math.max(bars.bottom, imeBottom));
            return insets;
        });

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.VERTICAL);
        bar.setGravity(Gravity.CENTER);
        bar.setPadding(dp(8), dp(4), dp(8), dp(4));
        bar.setBackgroundColor(Color.rgb(12,145,181));
        ImageView brandHeader = new ImageView(this);
        brandHeader.setImageResource(R.drawable.pixelsoft_header);
        brandHeader.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        bar.addView(brandHeader, new LinearLayout.LayoutParams(-1, dp(88)));
        root.addView(bar, new LinearLayout.LayoutParams(-1, dp(96)));

        setContentView(root);
        root.requestApplyInsets();
    }

    private void addSpace(LinearLayout box, int h) {
        SpaceView space = new SpaceView();
        box.addView(space, new LinearLayout.LayoutParams(1, dp(h)));
    }

    private class SpaceView extends View { SpaceView() { super(MainActivity.this); } }

    private void showHome() {
        homeScreen = true;
        base("Layanan PixelSoft");
        ScrollView scroll = new ScrollView(this);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(18), dp(20), dp(18), dp(20));

        TextView title = text("Layanan PixelSoft", 27);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        title.setTextColor(Color.rgb(18,91,135));
        box.addView(title);
        TextView sub = text("Pilih layanan yang Anda butuhkan", 15);
        sub.setTextColor(Color.rgb(76,99,112));
        box.addView(sub);
        addSpace(box, 14);

        LinearLayout row1 = new LinearLayout(this);
        row1.setOrientation(LinearLayout.HORIZONTAL);
        row1.addView(serviceCard("📷  CETAK FOTO & GAMBAR", "Foto, pas foto & gambar", true, v -> showPhotoMenu()), new LinearLayout.LayoutParams(0, dp(128), 1));
        LinearLayout.LayoutParams p2 = new LinearLayout.LayoutParams(0, dp(128), 1); p2.leftMargin = dp(10);
        row1.addView(serviceCard("🖨️  PRINT", "Dokumen & berkas", false, v -> Toast.makeText(this, "Layanan Print segera hadir.", Toast.LENGTH_SHORT).show()), p2);
        box.addView(row1);
        addSpace(box, 10);

        LinearLayout row2 = new LinearLayout(this);
        row2.setOrientation(LinearLayout.HORIZONTAL);
        row2.addView(serviceCard("⌨️  PENGETIKAN", "Surat & dokumen", true, v -> showTypingMenu()), new LinearLayout.LayoutParams(0, dp(128), 1));
        LinearLayout.LayoutParams p4 = new LinearLayout.LayoutParams(0, dp(128), 1); p4.leftMargin = dp(10);
        row2.addView(serviceCard("💻  LAYANAN DIGITAL", "Segera hadir", false, v -> Toast.makeText(this, "Layanan Digital sedang dikembangkan.", Toast.LENGTH_SHORT).show()), p4);
        box.addView(row2);
        addSpace(box, 16);

        Button help = button("ⓘ  Cara menggunakan   ›", false);
        help.setGravity(Gravity.CENTER_VERTICAL | Gravity.LEFT);
        help.setOnClickListener(v -> showHowToUse());
        box.addView(help, new LinearLayout.LayoutParams(-1, dp(50)));
        scroll.addView(box);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        TextView foot = text("PixelSoft • Solusi Cetak & Layanan Digital", 12);
        foot.setGravity(Gravity.CENTER); foot.setTextColor(Color.rgb(107,124,136));
        root.addView(foot, new LinearLayout.LayoutParams(-1, dp(38)));
    }

    private LinearLayout serviceCard(String title, String sub, boolean enabled, View.OnClickListener click) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setGravity(Gravity.CENTER_VERTICAL);
        card.setPadding(dp(12), dp(10), dp(10), dp(10));
        card.setBackgroundResource(R.drawable.drawable_card);
        TextView t = text(title, 15); t.setTypeface(null, android.graphics.Typeface.BOLD);
        t.setTextColor(enabled ? Color.rgb(18,91,135) : Color.rgb(140,150,157));
        TextView s = label(sub); s.setTextSize(12);
        card.addView(t); card.addView(s);
        if (!enabled) { TextView soon = label("Dalam pengembangan"); soon.setTextSize(11); card.addView(soon); }
        card.setAlpha(enabled ? 1f : .72f);
        card.setOnClickListener(click);
        return card;
    }

    private void showPhotoMenu() {
        homeScreen = false;
        base("Cetak Foto & Gambar");
        ScrollView scroll = new ScrollView(this);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(18), dp(18), dp(18), dp(24));
        TextView title = text("Cetak Foto & Gambar", 25);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        box.addView(title);
        box.addView(label("Pilih layanan yang ingin Anda gunakan."));
        addSpace(box, 14);

        Button cetak = button("📷  Cetak Foto\nFoto, pas foto & gambar", true);
        cetak.setGravity(Gravity.CENTER_VERTICAL | Gravity.LEFT);
        cetak.setOnClickListener(v -> pickImages());
        box.addView(cetak, new LinearLayout.LayoutParams(-1, dp(72)));
        addSpace(box, 10);

        Button susun = button("🖼️  Susun Foto ke Media Cetak\nAtur foto yang sudah jadi ke dalam satu lembar siap cetak", false);
        susun.setGravity(Gravity.CENTER_VERTICAL | Gravity.LEFT);
        susun.setOnClickListener(v -> startLayoutPhotoSelection());
        box.addView(susun, new LinearLayout.LayoutParams(-1, dp(84)));
        addSpace(box, 10);

        Button hvs = button("📄  Gambar di HVS\nCetak gambar atau beberapa gambar pada HVS", false);
        hvs.setGravity(Gravity.CENTER_VERTICAL | Gravity.LEFT);
        hvs.setOnClickListener(v -> pickImages());
        box.addView(hvs, new LinearLayout.LayoutParams(-1, dp(72)));
        scroll.addView(box);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
    }

    private void startLayoutPhotoSelection() {
        layoutPhotos.clear();
        addingPhotos = false;
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.setType("image/*");
        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(i, PICK_LAYOUT_IMAGE);
    }

    private void addMoreLayoutPhoto() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.setType("image/*");
        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(i, PICK_LAYOUT_IMAGE);
    }

    private void showTypingMenu() {
        homeScreen = false;
        base("Pengetikan");
        ScrollView scroll = new ScrollView(this);
        LinearLayout box = new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(18), dp(18), dp(18), dp(20));
        TextView title = text("Pengetikan PixelSoft", 25); title.setTypeface(null, android.graphics.Typeface.BOLD);
        box.addView(title);
        box.addView(label("Pilih jenis surat yang ingin dibuat."));
        addSpace(box, 14);
        Button jual = button("📄  Surat Jual Beli\nIsi data → Buat surat Word", true);
        jual.setGravity(Gravity.CENTER_VERTICAL | Gravity.LEFT);
        jual.setOnClickListener(v -> showSuratJualBeliForm());
        box.addView(jual, new LinearLayout.LayoutParams(-1, dp(72)));
        addSpace(box, 10);
        Button soon = button("📋  Surat Pernyataan\nSegera hadir", false);
        soon.setGravity(Gravity.CENTER_VERTICAL | Gravity.LEFT);
        soon.setAlpha(.65f);
        box.addView(soon, new LinearLayout.LayoutParams(-1, dp(72)));
        addSpace(box, 10);
        Button soon2 = button("📋  Surat Kuasa\nSegera hadir", false);
        soon2.setGravity(Gravity.CENTER_VERTICAL | Gravity.LEFT); soon2.setAlpha(.65f);
        box.addView(soon2, new LinearLayout.LayoutParams(-1, dp(72)));
        scroll.addView(box); root.addView(scroll, new LinearLayout.LayoutParams(-1,0,1));
    }

    private void showHowToUse() {
        final android.app.Dialog d = new android.app.Dialog(this);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(18), dp(20), dp(16));
        TextView title = text("Cara menggunakan PixelSoft", 19);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        box.addView(title);
        TextView body = text("1. Pilih foto atau gambar dari galeri HP Anda.\n\n2. Atur ukuran, jumlah, dan kebutuhan cetak.\n\n3. Periksa ringkasan pesanan.\n\n4. Kirim pesanan ke WhatsApp PixelSoft.\n\n💡 Untuk tugas sekolah, pilih Gambar di HVS.", 14);
        box.addView(body, new LinearLayout.LayoutParams(-1, -2));
        Button ok = button("Mengerti", true);
        ok.setOnClickListener(v -> d.dismiss());
        LinearLayout.LayoutParams op = new LinearLayout.LayoutParams(-1, dp(50));
        op.topMargin = dp(10);
        box.addView(ok, op);
        d.setContentView(box);
        android.view.Window w = d.getWindow();
        if (w != null) w.setBackgroundDrawableResource(android.R.color.white);
        d.show();
    }

    @Override public void onBackPressed() {
        if (!homeScreen) {
            // From order/summary screens, return to Home instead of closing the app.
            items.clear();
            selectedUris.clear();
            addingPhotos = false;
            customerNote = "";
            showHome();
            return;
        }
        // On Home, the normal Android Back action exits the app.
        super.onBackPressed();
    }

    private void pickImages() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.setType("image/*");
        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(i, PICK_IMAGES);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_LAYOUT_IMAGE) {
            if (resultCode != RESULT_OK || data == null) return;
            ArrayList<Uri> picked = new ArrayList<>();
            if (data.getClipData() != null) {
                for (int x=0; x<data.getClipData().getItemCount(); x++) picked.add(data.getClipData().getItemAt(x).getUri());
            } else if (data.getData() != null) picked.add(data.getData());
            for (Uri u : picked) {
                if (layoutPhotos.size() >= 30) break;
                LayoutPhoto lp = new LayoutPhoto(u);
                lp.bitmap = loadBitmap(u);
                if (lp.bitmap != null) layoutPhotos.add(lp);
            }
            if (!layoutPhotos.isEmpty()) showLayoutEditor();
            return;
        }
        if (requestCode != PICK_IMAGES || resultCode != RESULT_OK || data == null) {
            addingPhotos = false;
            return;
        }

        ArrayList<Uri> picked = new ArrayList<>();
        if (data.getClipData() != null) {
            int n = data.getClipData().getItemCount();
            for (int x = 0; x < n; x++) picked.add(data.getClipData().getItemAt(x).getUri());
        } else if (data.getData() != null) {
            picked.add(data.getData());
        }
        if (picked.isEmpty()) { addingPhotos = false; return; }

        int added = 0;
        if (addingPhotos && !items.isEmpty()) {
            for (Uri u : picked) {
                if (items.size() >= MAX_PHOTOS) break;
                if (selectedUris.contains(u)) continue;
                selectedUris.add(u);
                items.add(new OrderItem(u));
                added++;
            }
            if (picked.size() > added) {
                Toast.makeText(this, "Sebagian foto tidak ditambahkan. Maksimal 10 foto dan foto duplikat dilewati.", Toast.LENGTH_LONG).show();
            }
        } else {
            selectedUris.clear();
            items.clear();
            for (Uri u : picked) {
                if (items.size() >= MAX_PHOTOS) break;
                if (selectedUris.contains(u)) continue;
                selectedUris.add(u);
                items.add(new OrderItem(u));
            }
            if (picked.size() > items.size()) {
                Toast.makeText(this, "Maksimal 10 foto. Foto duplikat tidak ditambahkan.", Toast.LENGTH_LONG).show();
            }
        }

        addingPhotos = false;
        if (!items.isEmpty()) showEditor();
    }

    private Bitmap loadBitmap(Uri uri) {
        try {
            java.io.InputStream in = getContentResolver().openInputStream(uri);
            Bitmap b = BitmapFactory.decodeStream(in);
            if (in != null) in.close();
            return b;
        } catch (Exception e) { return null; }
    }

    private void showLayoutEditor() {
        homeScreen = false;
        base("Susun Foto ke Media Cetak");
        ScrollView scroll = new ScrollView(this);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(12), dp(12), dp(12), dp(20));

        TextView title = text("Susun Foto ke Media Cetak", 22);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        box.addView(title);
        box.addView(label("Geser foto dengan jari. Foto yang sama boleh digunakan berkali-kali."));
        addSpace(box, 8);

        layoutCanvas = new LayoutCanvas();
        box.addView(layoutCanvas, new LinearLayout.LayoutParams(-1, dp(390)));
        addSpace(box, 8);

        TextView selected = text("Pilih foto pada media, lalu tentukan ukurannya.", 13);
        selected.setTag("layoutSelectedLabel");
        box.addView(selected);

        LinearLayout sizeRow = new LinearLayout(this);
        sizeRow.setGravity(Gravity.CENTER_VERTICAL);
        String[] sizes = {"2×3 cm", "3×4 cm", "4×6 cm"};
        for (String sz : sizes) {
            Button b = button(sz, false);
            b.setTextSize(13);
            b.setOnClickListener(v -> {
                LayoutPhoto lp = getSelectedLayoutPhoto();
                if (lp == null) { Toast.makeText(this, "Pilih foto terlebih dahulu.", Toast.LENGTH_SHORT).show(); return; }
                lp.size = ((Button)v).getText().toString();
                layoutCanvas.invalidate();
            });
            LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(0, dp(48), 1);
            if (sizeRow.getChildCount() > 0) bp.leftMargin = dp(6);
            sizeRow.addView(b, bp);
        }
        box.addView(sizeRow);
        addSpace(box, 8);

        Button add = button("＋  Tambah Foto", false);
        add.setOnClickListener(v -> addMoreLayoutPhoto());
        box.addView(add, new LinearLayout.LayoutParams(-1, dp(50)));
        addSpace(box, 6);

        Button remove = button("🗑  Hapus Foto Terpilih", false);
        remove.setTextColor(Color.rgb(190,65,45));
        remove.setBackgroundResource(R.drawable.drawable_danger_button);
        remove.setOnClickListener(v -> {
            if (layoutCanvas.selectedIndex < 0 || layoutCanvas.selectedIndex >= layoutPhotos.size()) {
                Toast.makeText(this, "Pilih foto yang ingin dihapus.", Toast.LENGTH_SHORT).show(); return;
            }
            layoutPhotos.remove(layoutCanvas.selectedIndex);
            layoutCanvas.selectedIndex = Math.min(layoutCanvas.selectedIndex, layoutPhotos.size()-1);
            layoutCanvas.invalidate();
        });
        box.addView(remove, new LinearLayout.LayoutParams(-1, dp(50)));
        addSpace(box, 10);

        Button make = button("✓  Buat File Siap Cetak", true);
        make.setOnClickListener(v -> createLayoutJpg());
        box.addView(make, new LinearLayout.LayoutParams(-1, dp(56)));

        scroll.addView(box);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
    }

    private LayoutPhoto getSelectedLayoutPhoto() {
        if (layoutCanvas == null || layoutCanvas.selectedIndex < 0 || layoutCanvas.selectedIndex >= layoutPhotos.size()) return null;
        return layoutPhotos.get(layoutCanvas.selectedIndex);
    }

    private int layoutWidthPx(String size) { return size.startsWith("2") ? 236 : size.startsWith("3") ? 354 : 472; }
    private int layoutHeightPx(String size) { return size.startsWith("2") ? 354 : size.startsWith("3") ? 472 : 709; }

    private void createLayoutJpg() {
        if (layoutPhotos.isEmpty()) { Toast.makeText(this,"Belum ada foto.",Toast.LENGTH_SHORT).show(); return; }
        try {
            final int W=1200, H=1800;
            Bitmap out=Bitmap.createBitmap(W,H,Bitmap.Config.ARGB_8888);
            Canvas c=new Canvas(out); c.drawColor(Color.WHITE);
            Paint p=new Paint(Paint.ANTI_ALIAS_FLAG|Paint.FILTER_BITMAP_FLAG);
            float sx=W/(float)layoutCanvas.getWidth(), sy=H/(float)layoutCanvas.getHeight();
            for (LayoutPhoto lp: layoutPhotos) {
                float cx=lp.x*sx, cy=lp.y*sy;
                float rw=layoutWidthPx(lp.size)*sx, rh=layoutHeightPx(lp.size)*sy;
                float left=cx-rw/2f, top=cy-rh/2f;
                RectF dst=new RectF(left,top,left+rw,top+rh);
                if (lp.bitmap != null) {
                    float bw=lp.bitmap.getWidth(), bh=lp.bitmap.getHeight();
                    float scale=Math.min(rw/bw,rh/bh);
                    float dw=bw*scale, dh=bh*scale;
                    RectF fit=new RectF(left+(rw-dw)/2f,top+(rh-dh)/2f,left+(rw+dw)/2f,top+(rh+dh)/2f);
                    c.drawBitmap(lp.bitmap,null,fit,p);
                }
            }
            File dir=new File(getExternalFilesDir("Documents"),"PixelSoft");
            if(!dir.exists())dir.mkdirs();
            File file=new File(dir,"SusunFoto_MediaCetak_"+System.currentTimeMillis()+".jpg");
            java.io.FileOutputStream fos=new java.io.FileOutputStream(file);
            out.compress(Bitmap.CompressFormat.JPEG,95,fos); fos.close(); out.recycle();
            shareLayoutJpg(file);
        } catch(Exception e) { Toast.makeText(this,"Gagal membuat file: "+e.getMessage(),Toast.LENGTH_LONG).show(); }
    }

    private void shareLayoutJpg(File file) {
        try {
            Uri uri=PixelSoftFileProvider.getUriForFile(this,file);
            Intent share=new Intent(Intent.ACTION_SEND);
            share.setType("image/jpeg");
            share.putExtra(Intent.EXTRA_STREAM,uri);
            share.putExtra(Intent.EXTRA_TEXT,"Halo PixelSoft, saya mengirim layout foto siap cetak.");
            share.putExtra("jid", PIXELSOFT_WA_NUMBER+"@s.whatsapp.net");
            share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            share.setPackage("com.whatsapp");
            startActivity(share);
        } catch(Exception e) { Toast.makeText(this,"WhatsApp belum terpasang atau file tidak dapat dikirim.",Toast.LENGTH_LONG).show(); }
    }

    private class LayoutCanvas extends View {
        Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG); int selectedIndex=-1; float downX,downY; boolean dragging;
        LayoutCanvas(){super(MainActivity.this); setBackgroundResource(R.drawable.drawable_card);}
        protected void onDraw(Canvas c){
            super.onDraw(c);
            float pad=dp(18), w=getWidth()-pad*2, h=getHeight()-pad*2;
            float sheetW=w, sheetH=w*1.5f;
            if(sheetH>h){sheetH=h;sheetW=sheetH/1.5f;}
            float ox=(getWidth()-sheetW)/2f, oy=(getHeight()-sheetH)/2f;
            paint.setColor(Color.WHITE); c.drawRect(ox,oy,ox+sheetW,oy+sheetH,paint);
            paint.setStyle(Paint.Style.STROKE); paint.setColor(Color.LTGRAY); c.drawRect(ox,oy,ox+sheetW,oy+sheetH,paint); paint.setStyle(Paint.Style.FILL);
            float scale=sheetW/1200f;
            for(int i=0;i<layoutPhotos.size();i++){
                LayoutPhoto lp=layoutPhotos.get(i);
                if(lp.x==0&&lp.y==0){ lp.x=ox+sheetW/2f; lp.y=oy+sheetH/2f; }
                int rw=layoutWidthPx(lp.size), rh=layoutHeightPx(lp.size);
                float ww=rw*scale, hh=rh*scale, left=lp.x-ww/2, top=lp.y-hh/2;
                if(lp.bitmap!=null){float bw=lp.bitmap.getWidth(),bh=lp.bitmap.getHeight(), sc=Math.min(ww/bw,hh/bh);float dw=bw*sc,dh=bh*sc;RectF dst=new RectF(left+(ww-dw)/2,top+(hh-dh)/2,left+(ww+dw)/2,top+(hh+dh)/2);c.drawBitmap(lp.bitmap,null,dst,paint);}
                if(i==selectedIndex){paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(dp(2));paint.setColor(Color.rgb(12,145,181));c.drawRect(left,top,left+ww,top+hh,paint);paint.setStyle(Paint.Style.FILL);}
            }
        }
        public boolean onTouchEvent(MotionEvent e){
            if(e.getAction()==MotionEvent.ACTION_DOWN){downX=e.getX();downY=e.getY();selectedIndex=hit(e.getX(),e.getY());dragging=selectedIndex>=0;invalidate();return true;}
            if(e.getAction()==MotionEvent.ACTION_MOVE&&dragging){LayoutPhoto lp=layoutPhotos.get(selectedIndex);lp.x=e.getX();lp.y=e.getY();invalidate();return true;}
            if(e.getAction()==MotionEvent.ACTION_UP){dragging=false;invalidate();return true;} return true;
        }
        private int hit(float x,float y){
            for(int i=layoutPhotos.size()-1;i>=0;i--){LayoutPhoto lp=layoutPhotos.get(i);float scale=(getWidth()-dp(36))/1200f;float ww=layoutWidthPx(lp.size)*scale,hh=layoutHeightPx(lp.size)*scale;if(Math.abs(x-lp.x)<=ww/2&&Math.abs(y-lp.y)<=hh/2)return i;}return -1;
        }
    }

    private void showEditor() {
        homeScreen = false;
        base("Atur Pesanan");
        ScrollView scroll = new ScrollView(this);
        listContainer = new LinearLayout(this);
        listContainer.setOrientation(LinearLayout.VERTICAL);
        listContainer.setPadding(dp(12), dp(12), dp(12), dp(20));

        LinearLayout head = new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = text("Foto pesanan", 22);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        head.addView(title, new LinearLayout.LayoutParams(0, -2, 1));
        countText = text(items.size() + " / " + MAX_PHOTOS + " foto", 14);
        countText.setGravity(Gravity.CENTER);
        countText.setTextColor(Color.rgb(12,145,181));
        countText.setBackgroundResource(R.drawable.drawable_pill);
        head.addView(countText, new LinearLayout.LayoutParams(dp(105), dp(38)));
        listContainer.addView(head);

        TextView helper = label("Atur ukuran dan jumlah untuk setiap foto.");
        listContainer.addView(helper);

        for (int i = 0; i < items.size(); i++) addItemView(i);

        Button add = button("＋  Tambah Foto", false);
        add.setOnClickListener(v -> {
            if (items.size() >= MAX_PHOTOS) {
                Toast.makeText(this, "Sudah mencapai maksimal 10 foto.", Toast.LENGTH_SHORT).show();
                return;
            }
            addingPhotos = true;
            pickImages();
        });
        listContainer.addView(add, new LinearLayout.LayoutParams(-1, dp(50)));

        addSpace(listContainer, 8);
        TextView noteLabel = text("Catatan untuk PixelSoft (opsional)", 16);
        noteLabel.setTypeface(null, android.graphics.Typeface.BOLD);
        listContainer.addView(noteLabel);
        noteInput = new EditText(this);
        noteInput.setHint("Contoh: Tolong cetak sore, akan saya ambil langsung.");
        noteInput.setText(customerNote);
        noteInput.setTextSize(14);
        noteInput.setGravity(Gravity.TOP | Gravity.START);
        noteInput.setMinLines(3);
        noteInput.setPadding(dp(12), dp(10), dp(12), dp(10));
        noteInput.setOnFocusChangeListener((v, hasFocus) -> {
            if (hasFocus) {
                v.postDelayed(() -> scroll.smoothScrollTo(0, Math.max(0, v.getBottom() - dp(80))), 180);
            }
        });
        listContainer.addView(noteInput, new LinearLayout.LayoutParams(-1, dp(90)));

        addSpace(listContainer, 10);
        Button next = button("Lanjut ke Ringkasan  →", true);
        next.setOnClickListener(v -> {
            saveNote();
            showSummary();
        });
        listContainer.addView(next, new LinearLayout.LayoutParams(-1, dp(54)));

        scroll.addView(listContainer);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
    }

    private void addItemView(int index) {
        OrderItem item = items.get(index);
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(12), dp(10), dp(12), dp(12));
        card.setBackgroundResource(R.drawable.drawable_card);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, -2);
        cp.bottomMargin = dp(10);
        listContainer.addView(card, cp);

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        ImageView iv = new ImageView(this);
        iv.setImageURI(item.uri);
        iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
        top.addView(iv, new LinearLayout.LayoutParams(dp(92), dp(92)));

        LinearLayout nameBox = new LinearLayout(this);
        nameBox.setOrientation(LinearLayout.VERTICAL);
        nameBox.setPadding(dp(12), 0, dp(4), 0);
        TextView name = text("Foto " + (index + 1), 18);
        name.setTypeface(null, android.graphics.Typeface.BOLD);
        nameBox.addView(name);
        TextView hint = label("Atur kebutuhan cetak di bawah");
        nameBox.addView(hint);
        top.addView(nameBox, new LinearLayout.LayoutParams(0, -2, 1));

        Button remove = button("🗑 Hapus", false);
        remove.setTextSize(12);
        remove.setTextColor(Color.rgb(190,65,45));
        remove.setBackgroundResource(R.drawable.drawable_danger_button);
        remove.setOnClickListener(v -> {
            selectedUris.remove(item.uri);
            items.remove(item);
            if (items.isEmpty()) showHome(); else showEditor();
            Toast.makeText(this, "Foto dihapus dari pesanan.", Toast.LENGTH_SHORT).show();
        });
        top.addView(remove, new LinearLayout.LayoutParams(dp(76), dp(42)));
        card.addView(top);

        addSpace(card, 6);
        TextView typeLabel = label("Jenis cetak");
        card.addView(typeLabel);
        LinearLayout typeRow = new LinearLayout(this);
        typeRow.setGravity(Gravity.CENTER_VERTICAL);
        Button photoType = button("📷\nCetak Foto", false);
        photoType.setTextSize(12);
        Button hvsType = button("📄\nGambar di HVS", false);
        hvsType.setTextSize(12);
        typeRow.addView(photoType, new LinearLayout.LayoutParams(0, dp(62), 1));
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(0, dp(62), 1);
        hp.leftMargin = dp(8);
        typeRow.addView(hvsType, hp);
        card.addView(typeRow);
        View.OnClickListener typeClick = v -> {
            item.printType = (v == photoType) ? "Cetak Foto" : "Gambar di HVS";
            showEditor();
        };
        photoType.setOnClickListener(typeClick);
        hvsType.setOnClickListener(typeClick);
        styleTypeButton(photoType, item.printType.equals("Cetak Foto"));
        styleTypeButton(hvsType, item.printType.equals("Gambar di HVS"));

        LinearLayout row = new LinearLayout(this);
        row.setTag("photoSizeRow");
        row.setGravity(Gravity.CENTER_VERTICAL);
        TextView sl = label("Ukuran");
        row.addView(sl, new LinearLayout.LayoutParams(dp(68), dp(50)));
        Spinner sp = new Spinner(this);
        ArrayAdapter<String> ad = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, photoSizes);
        sp.setAdapter(ad);
        sp.setSelection(indexOf(photoSizes, item.size));
        sp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onNothingSelected(AdapterView<?> p) {}
            public void onItemSelected(AdapterView<?> p, View v, int pos, long id) {
                item.size = photoSizes[pos];
                updateOptions(card, item);
            }
        });
        row.addView(sp, new LinearLayout.LayoutParams(0, dp(50), 1));
        TextView ql = label("Jumlah");
        ql.setGravity(Gravity.CENTER_VERTICAL);
        row.addView(ql, new LinearLayout.LayoutParams(dp(68), dp(50)));
        EditText qty = new EditText(this);
        qty.setInputType(2);
        qty.setText(String.valueOf(item.qty));
        qty.setSelectAllOnFocus(true);
        qty.setGravity(Gravity.CENTER);
        qty.setOnFocusChangeListener((v, has) -> {
            if (!has) {
                try {
                    int q = Integer.parseInt(qty.getText().toString().trim());
                    item.qty = Math.min(99, Math.max(1, q));
                } catch (Exception e) { item.qty = 1; }
                qty.setText(String.valueOf(item.qty));
            }
        });
        row.addView(qty, new LinearLayout.LayoutParams(dp(55), dp(50)));
        card.addView(row);

        updateOptions(card, item);
    }

    private void styleTypeButton(Button b, boolean active) {
        b.setTextColor(active ? Color.WHITE : Color.rgb(22,50,71));
        b.setBackgroundResource(active ? R.drawable.drawable_primary_button : R.drawable.drawable_secondary_button);
    }

    private boolean isPasFoto(String size) { return size.startsWith("Pas Foto"); }

    private void updateOptions(LinearLayout card, OrderItem item) {
        View sizeRow = card.findViewWithTag("photoSizeRow");
        if (sizeRow != null) sizeRow.setVisibility(item.printType.equals("Cetak Foto") ? View.VISIBLE : View.GONE);

        View old = card.findViewWithTag("printOptions");
        if (old instanceof ViewGroup) ((ViewGroup) old.getParent()).removeView(old);

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setTag("printOptions");
        card.addView(box);

        if (item.printType.equals("Cetak Foto")) {
            CheckBox fit = new CheckBox(this);
            fit.setText("Sesuaikan foto dengan ukuran (crop bila perlu)");
            fit.setTextSize(13);
            fit.setChecked(item.fit);
            fit.setOnCheckedChangeListener((b,c) -> item.fit = c);
            box.addView(fit);

            if (isPasFoto(item.size)) {
                TextView pl = text("Pengaturan Pas Foto", 14);
                pl.setTextColor(Color.rgb(12,145,181));
                pl.setTypeface(null, android.graphics.Typeface.BOLD);
                box.addView(pl);

                CheckBox replace = new CheckBox(this);
                replace.setText("Ganti latar foto");
                replace.setTextSize(13);
                replace.setChecked(!item.background.equals("Tidak diganti"));
                box.addView(replace);

                Spinner bg = new Spinner(this);
                String[] backgrounds = {"Tidak diganti", "Merah", "Biru"};
                ArrayAdapter<String> bgAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, backgrounds);
                bg.setAdapter(bgAdapter);
                bg.setSelection(indexOf(backgrounds, item.background));
                bg.setEnabled(replace.isChecked());
                bg.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                    public void onNothingSelected(AdapterView<?> p) {}
                    public void onItemSelected(AdapterView<?> p, View v, int pos, long id) { item.background = backgrounds[pos]; }
                });
                replace.setOnCheckedChangeListener((b, checked) -> {
                    bg.setEnabled(checked);
                    if (!checked) { item.background = "Tidak diganti"; bg.setSelection(0); }
                    else if (item.background.equals("Tidak diganti")) { item.background = "Merah"; bg.setSelection(1); }
                });
                box.addView(bg, new LinearLayout.LayoutParams(dp(155), dp(50)));
            }
        } else {
            TextView hl = text("Pengaturan HVS", 14);
            hl.setTextColor(Color.rgb(12,145,181));
            hl.setTypeface(null, android.graphics.Typeface.BOLD);
            box.addView(hl);

            addChoice(box, "Kertas", hvsPapers, item.paper, value -> item.paper = value);
            addChoice(box, "Cetak", hvsColors, item.colorMode, value -> item.colorMode = value);
            TextView layoutLabel = label("Gambar per lembar");
            box.addView(layoutLabel);
            LinearLayout layoutRow = new LinearLayout(this);
            layoutRow.setOrientation(LinearLayout.HORIZONTAL);
            layoutRow.setGravity(Gravity.CENTER_VERTICAL);
            for (int i = 0; i < hvsLayouts.length; i++) {
                final String value = hvsLayouts[i];
                Button b = button(String.valueOf(i + 1), false);
                b.setTextSize(14);
                styleLayoutButton(b, item.layout.equals(value));
                b.setOnClickListener(v -> { item.layout = value; updateOptions(card, item); });
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(42), 1);
                if (i > 0) lp.leftMargin = dp(5);
                layoutRow.addView(b, lp);
            }
            box.addView(layoutRow);
            TextView hint = label("Cocok untuk tugas sekolah, gambar, materi, dan dokumen bergambar.");
            hint.setTextSize(12);
            box.addView(hint);
        }
    }

    private void styleLayoutButton(Button b, boolean active) {
        b.setTextColor(active ? Color.WHITE : Color.rgb(22,50,71));
        b.setBackgroundResource(active ? R.drawable.drawable_primary_button : R.drawable.drawable_secondary_button);
    }

    private interface StringSetter { void set(String value); }

    private void addChoice(LinearLayout box, String labelText, String[] values, String selected, StringSetter setter) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        TextView l = label(labelText);
        row.addView(l, new LinearLayout.LayoutParams(dp(78), dp(48)));
        Spinner sp = new Spinner(this);
        ArrayAdapter<String> ad = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, values);
        sp.setAdapter(ad);
        sp.setSelection(indexOf(values, selected));
        sp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onNothingSelected(AdapterView<?> p) {}
            public void onItemSelected(AdapterView<?> p, View v, int pos, long id) { setter.set(values[pos]); }
        });
        row.addView(sp, new LinearLayout.LayoutParams(0, dp(48), 1));
        box.addView(row);
    }

    private int indexOf(String[] a, String s) {
        for (int i=0;i<a.length;i++) if (a[i].equals(s)) return i;
        return 0;
    }

    private void saveNote() {
        if (noteInput != null) customerNote = noteInput.getText().toString().trim();
    }

    private void showSummary() {
        homeScreen = false;
        saveNote();
        for (OrderItem item : items) item.qty = Math.min(99, Math.max(1, item.qty));
        base("Ringkasan Pesanan");
        ScrollView scroll = new ScrollView(this);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(16), dp(16), dp(16), dp(20));

        TextView title = text("Pesanan Anda", 23);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        box.addView(title);
        TextView sub = label("Periksa kembali sebelum dikirim ke WhatsApp.");
        box.addView(sub);
        addSpace(box, 8);

        int total = 0;
        for (int i=0;i<items.size();i++) {
            OrderItem o = items.get(i);
            total += o.qty;
            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.HORIZONTAL);
            card.setGravity(Gravity.CENTER_VERTICAL);
            card.setPadding(dp(12), dp(8), dp(12), dp(8));
            card.setBackgroundResource(R.drawable.drawable_card);
            ImageView iv = new ImageView(this);
            iv.setImageURI(o.uri);
            iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
            card.addView(iv, new LinearLayout.LayoutParams(dp(58), dp(58)));
            String detail;
            if (o.printType.equals("Gambar di HVS")) {
                detail = "Gambar di HVS\n" + o.paper + " • " + o.colorMode + "\n" + o.layout + " • " + o.qty + " lembar";
            } else {
                detail = o.size + " • " + o.qty + " lembar\n" +
                        (o.fit ? "Sesuaikan/crop" : "Tanpa crop") +
                        (isPasFoto(o.size) ? " • Latar: " + o.background : "");
            }
            TextView t = text("Foto " + (i+1) + "\n" + detail, 14);
            t.setPadding(dp(10), dp(4), dp(4), dp(4));
            card.addView(t, new LinearLayout.LayoutParams(0, -2, 1));
            LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, -2);
            cp.bottomMargin = dp(8);
            box.addView(card, cp);
        }

        TextView totalText = text("TOTAL  •  " + total + " LEMBAR", 20);
        totalText.setTypeface(null, android.graphics.Typeface.BOLD);
        totalText.setTextColor(Color.rgb(12,145,181));
        totalText.setGravity(Gravity.CENTER);
        totalText.setPadding(8, dp(12), 8, dp(12));
        box.addView(totalText);

        if (!customerNote.isEmpty()) {
            TextView nt = text("Catatan\n" + customerNote, 14);
            nt.setBackgroundResource(R.drawable.drawable_card);
            box.addView(nt, new LinearLayout.LayoutParams(-1, -2));
        }

        addSpace(box, 12);
        Button edit = button("←  Kembali Atur Pesanan", false);
        edit.setOnClickListener(v -> showEditor());
        box.addView(edit, new LinearLayout.LayoutParams(-1, dp(50)));
        addSpace(box, 6);
        Button send = button("📲  Kirim Pesanan ke WhatsApp", true);
        send.setTextSize(16);
        send.setOnClickListener(v -> sendToWhatsApp());
        box.addView(send, new LinearLayout.LayoutParams(-1, dp(56)));

        TextView note = label("Foto akan dilampirkan ke WhatsApp bersama detail pesanan.");
        note.setGravity(Gravity.CENTER);
        box.addView(note, new LinearLayout.LayoutParams(-1, dp(46)));

        scroll.addView(box);
        root.addView(scroll, new LinearLayout.LayoutParams(-1,0,1));
    }

    private EditText suratField(LinearLayout box, String key, String labelText, String hint) {
        TextView l = text(labelText, 14); l.setTypeface(null, android.graphics.Typeface.BOLD); box.addView(l);
        EditText e = new EditText(this); e.setHint(hint); e.setTextSize(14); e.setSingleLine(false); e.setPadding(dp(12), dp(8), dp(12), dp(8));
        box.addView(e, new LinearLayout.LayoutParams(-1, dp(54)));
        suratFields.put(key, e); return e;
    }

    private void showSuratJualBeliForm() {
        homeScreen = false; suratFields.clear();
        base("Surat Jual Beli");
        ScrollView scroll = new ScrollView(this);
        LinearLayout box = new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(16),dp(16),dp(16),dp(24));
        TextView title=text("Surat Jual Beli",25); title.setTypeface(null,android.graphics.Typeface.BOLD); box.addView(title);
        box.addView(label("Isi data berikut. Surat akan dibuat otomatis sesuai format PixelSoft.")); addSpace(box,12);
        addSectionLabel(box,"1. PIHAK PERTAMA — PENJUAL");
        suratField(box,"NAMA_PENJUAL","Nama lengkap","Contoh: Zufri Harahap");
        suratField(box,"TTL_PENJUAL","Tempat / Tanggal lahir","Contoh: Padangsidimpuan, 12 Mei 1970");
        suratField(box,"AGAMA_PENJUAL","Agama","Contoh: Islam");
        suratField(box,"PEKERJAAN_PENJUAL","Pekerjaan","Contoh: Petani");
        suratField(box,"ALAMAT_PENJUAL","Alamat","Alamat lengkap");
        addSpace(box,10); addSectionLabel(box,"2. PIHAK KEDUA — PEMBELI");
        suratField(box,"NAMA_PEMBELI","Nama lengkap","Contoh: Riswan");
        suratField(box,"TTL_PEMBELI","Tempat / Tanggal lahir","Contoh: Padangsidimpuan, 10 Juli 1975");
        suratField(box,"AGAMA_PEMBELI","Agama","Contoh: Islam");
        suratField(box,"PEKERJAAN_PEMBELI","Pekerjaan","Contoh: Petani");
        suratField(box,"ALAMAT_PEMBELI","Alamat","Alamat lengkap");
        addSpace(box,10); addSectionLabel(box,"3. DATA TANAH");
        suratField(box,"LUAS_TANAH","Luas / Ukuran Tanah","Contoh: 2 Ha (Dua Hektar)");
        suratField(box,"LOKASI_TANAH","Letak tanah (opsional)","Boleh dikosongkan");
        EditText desaTanah = suratField(box,"DESA_TANAH","Desa / Kelurahan","Nama desa");
        suratField(box,"KECAMATAN_TANAH","Kecamatan","Nama kecamatan");
        suratField(box,"KABUPATEN_TANAH","Kabupaten","Nama kabupaten");
        EditText hargaJual = suratField(box,"HARGA_NUMERIK","Harga jual","Contoh: 35.000.000");
        EditText hargaTerbilang = suratField(box,"HARGA_TERBILANG","Harga dalam tulisan (otomatis)","Terisi otomatis dari Harga jual");
        hargaTerbilang.setFocusable(false);
        hargaTerbilang.setClickable(false);
        hargaTerbilang.setLongClickable(false);
        hargaTerbilang.setTextColor(Color.DKGRAY);
        hargaJual.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                hargaTerbilang.setText(terbilangRupiah(s.toString()));
            }
            @Override public void afterTextChanged(Editable s) {}
        });
        addSpace(box,10); addSectionLabel(box,"4. BATAS-BATAS TANAH");
        suratField(box,"BATAS_TIMUR","Sebelah Timur","Berbatasan dengan...");
        suratField(box,"BATAS_BARAT","Sebelah Barat","Berbatasan dengan...");
        suratField(box,"BATAS_UTARA","Sebelah Utara","Berbatasan dengan...");
        suratField(box,"BATAS_SELATAN","Sebelah Selatan","Berbatasan dengan...");
        addSpace(box,10); addSectionLabel(box,"5. DATA SURAT & SAKSI");
        EditText tempat=suratField(box,"TEMPAT_SURAT","Tempat surat dibuat","Contoh: Sidadi");
        Button date=button("📅  Pilih tanggal surat",false); box.addView(date,new LinearLayout.LayoutParams(-1,dp(50))); date.setOnClickListener(v->pickSuratDate(date));
        suratField(box,"NAMA_SAKSI_1","Nama saksi 1","Nama lengkap");
        suratField(box,"NAMA_SAKSI_2","Nama saksi 2","Nama lengkap");
        EditText namaDesa = suratField(box,"NAMA_DESA","Nama Desa / Kelurahan (otomatis)","Mengikuti Data Tanah Desa / Kelurahan");
        namaDesa.setFocusable(false);
        namaDesa.setClickable(false);
        namaDesa.setLongClickable(false);
        namaDesa.setTextColor(Color.DKGRAY);
        desaTanah.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                namaDesa.setText(s.toString());
            }
            @Override public void afterTextChanged(Editable s) {}
        });
        namaDesa.setText(desaTanah.getText().toString());
        suratField(box,"NAMA_KEPALA_DESA","Nama Kepala Desa / Lurah","Nama lengkap");
        addSpace(box,14);
        Button preview=button("Lihat Preview Surat  →",true); preview.setOnClickListener(v->previewSuratJualBeli());
        box.addView(preview,new LinearLayout.LayoutParams(-1,dp(56)));
        scroll.addView(box); root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
    }

    private void addSectionLabel(LinearLayout box,String s){ TextView t=text(s,15); t.setTypeface(null,android.graphics.Typeface.BOLD); t.setTextColor(Color.rgb(12,145,181)); t.setPadding(dp(6),dp(10),dp(6),dp(6)); box.addView(t); }

    private void pickSuratDate(Button button){
        Calendar c=Calendar.getInstance(); DatePickerDialog dlg=new DatePickerDialog(this,(v,y,m,d)->{ suratTanggal=d+" "+new String[]{"Januari","Februari","Maret","April","Mei","Juni","Juli","Agustus","September","Oktober","November","Desember"}[m]+" "+y; button.setText("📅  "+suratTanggal); },c.get(Calendar.YEAR),c.get(Calendar.MONTH),c.get(Calendar.DAY_OF_MONTH)); dlg.show();
    }

    private Map<String,String> getSuratData(){
        Map<String,String> d=new LinkedHashMap<>();
        for(Map.Entry<String,EditText> e:suratFields.entrySet()) d.put(e.getKey(),e.getValue().getText().toString().trim());
        d.put("TANGGAL_SURAT",suratTanggal);
        return d;
    }

    private boolean validateSurat(Map<String,String> d){
        String[] req={"NAMA_PENJUAL","TTL_PENJUAL","AGAMA_PENJUAL","PEKERJAAN_PENJUAL","ALAMAT_PENJUAL","NAMA_PEMBELI","TTL_PEMBELI","AGAMA_PEMBELI","PEKERJAAN_PEMBELI","ALAMAT_PEMBELI","LUAS_TANAH","DESA_TANAH","KECAMATAN_TANAH","KABUPATEN_TANAH","HARGA_NUMERIK","HARGA_TERBILANG","BATAS_TIMUR","BATAS_BARAT","BATAS_UTARA","BATAS_SELATAN","TEMPAT_SURAT","NAMA_SAKSI_1","NAMA_SAKSI_2","NAMA_DESA","NAMA_KEPALA_DESA"};
        for(String k:req) if(d.get(k)==null||d.get(k).isEmpty()){ EditText e=suratFields.get(k); if(e!=null){e.requestFocus(); e.getParent().requestChildFocus(e,e);} Toast.makeText(this,"Mohon lengkapi: "+k.replace("_"," "),Toast.LENGTH_SHORT).show(); return false; }
        if(suratTanggal.isEmpty()){Toast.makeText(this,"Silakan pilih tanggal surat.",Toast.LENGTH_SHORT).show();return false;} return true;
    }

    private String suratPreviewText(Map<String,String> d){
        return "SURAT JUAL BELI\n\nYang bertanda tangan dibawah ini:\n\n"+
                "Nama : "+d.get("NAMA_PENJUAL")+"\nTempat/Tgl. lahir : "+d.get("TTL_PENJUAL")+"\nAgama : "+d.get("AGAMA_PENJUAL")+"\nPekerjaan : "+d.get("PEKERJAAN_PENJUAL")+"\nAlamat : "+d.get("ALAMAT_PENJUAL")+"\n\nDisebut sebagai Pihak Pertama (Penjual)\n\n"+
                "Nama : "+d.get("NAMA_PEMBELI")+"\nTempat/Tgl. lahir : "+d.get("TTL_PEMBELI")+"\nAgama : "+d.get("AGAMA_PEMBELI")+"\nPekerjaan : "+d.get("PEKERJAAN_PEMBELI")+"\nAlamat : "+d.get("ALAMAT_PEMBELI")+"\n\nDisebut sebagai Pihak Kedua (Pembeli)\n\n"+
                "Tanah ukuran "+d.get("LUAS_TANAH")+locationText(d)+" dengan harga Rp. "+d.get("HARGA_NUMERIK")+" ("+d.get("HARGA_TERBILANG")+").\n\n"+
                "Batas: Timur — "+d.get("BATAS_TIMUR")+"; Barat — "+d.get("BATAS_BARAT")+"; Utara — "+d.get("BATAS_UTARA")+"; Selatan — "+d.get("BATAS_SELATAN")+".";
    }

    private String locationText(Map<String,String> d){
        StringBuilder s = new StringBuilder();
        String lokasi = d.get("LOKASI_TANAH");
        if (lokasi != null && !lokasi.trim().isEmpty()) s.append(" terletak di ").append(lokasi.trim());
        s.append(", ").append(d.get("DESA_TANAH"));
        s.append(", ").append(d.get("KECAMATAN_TANAH"));
        s.append(", ").append(d.get("KABUPATEN_TANAH"));
        return s.toString();
    }

    private String terbilangRupiah(String input){
        String digits = input == null ? "" : input.replaceAll("[^0-9]", "");
        if (digits.isEmpty()) return "";
        try {
            long value = Long.parseLong(digits);
            if (value == 0) return "Nol Rupiah";
            return terbilang(value).trim() + " Rupiah";
        } catch (NumberFormatException e) {
            return "";
        }
    }

    private String terbilang(long n){
        final String[] angka={"","Satu","Dua","Tiga","Empat","Lima","Enam","Tujuh","Delapan","Sembilan","Sepuluh","Sebelas"};
        if(n<12) return angka[(int)n];
        if(n<20) return terbilang(n-10)+" Belas";
        if(n<100) return terbilang(n/10)+" Puluh"+(n%10==0?"":" "+terbilang(n%10));
        if(n<200) return "Seratus"+(n%100==0?"":" "+terbilang(n-100));
        if(n<1000) return terbilang(n/100)+" Ratus"+(n%100==0?"":" "+terbilang(n%100));
        if(n<2000) return "Seribu"+(n%1000==0?"":" "+terbilang(n-1000));
        if(n<1000000) return terbilang(n/1000)+" Ribu"+(n%1000==0?"":" "+terbilang(n%1000));
        if(n<1000000000) return terbilang(n/1000000)+" Juta"+(n%1000000==0?"":" "+terbilang(n%1000000));
        if(n<1000000000000L) return terbilang(n/1000000000)+" Miliar"+(n%1000000000==0?"":" "+terbilang(n%1000000000));
        return terbilang(n/1000000000000L)+" Triliun"+(n%1000000000000L==0?"":" "+terbilang(n%1000000000000L));
    }

    private void previewSuratJualBeli(){
        Map<String,String> d=getSuratData(); if(!validateSurat(d))return;
        final android.app.Dialog dlg=new android.app.Dialog(this); LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(18),dp(16),dp(18),dp(16));
        TextView title=text("Preview Surat Jual Beli",20); title.setTypeface(null,android.graphics.Typeface.BOLD); box.addView(title);
        ScrollView sv=new ScrollView(this); TextView body=text(suratPreviewText(d),13); body.setPadding(dp(4),dp(10),dp(4),dp(10)); sv.addView(body); box.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
        Button make=button("📄  Buat Word & Kirim ke WhatsApp",true); make.setOnClickListener(v->{dlg.dismiss(); generateAndShareSurat(d);}); box.addView(make,new LinearLayout.LayoutParams(-1,dp(56)));
        Button edit=button("← Kembali Edit Data",false); edit.setOnClickListener(v->dlg.dismiss()); box.addView(edit,new LinearLayout.LayoutParams(-1,dp(50)));
        dlg.setContentView(box); android.view.Window w=dlg.getWindow(); if(w!=null)w.setBackgroundDrawableResource(android.R.color.white); dlg.show();
    }

    private void generateAndShareSurat(Map<String,String> data){
        try{
            File file=DocxGenerator.createSuratJualBeli(this,data);
            Uri uri=androidxFileUri(file);
            Intent share=new Intent(Intent.ACTION_SEND); share.setType("application/vnd.openxmlformats-officedocument.wordprocessingml.document"); share.putExtra(Intent.EXTRA_STREAM,uri); share.putExtra(Intent.EXTRA_TEXT,"Halo PixelSoft, saya mengirim data Surat Jual Beli untuk diproses."); share.putExtra("jid", PIXELSOFT_WA_NUMBER + "@s.whatsapp.net"); share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION); share.setPackage("com.whatsapp");
            startActivity(share);
        }catch(Exception e){ Toast.makeText(this,"Gagal membuat file Word: "+e.getMessage(),Toast.LENGTH_LONG).show(); }
    }

    private Uri androidxFileUri(File file){
        // FileProvider is configured in the manifest; keep this helper isolated so the rest of the app remains unchanged.
        return PixelSoftFileProvider.getUriForFile(this,file);
    }

    private void sendToWhatsApp() {
        StringBuilder msg = new StringBuilder("Halo PixelSoft, saya ingin memesan cetak foto/gambar.\n\n");
        int total = 0;
        for (int i=0;i<items.size();i++) {
            OrderItem o = items.get(i);
            total += o.qty;
            msg.append(i+1).append(". Foto ").append(i+1).append(" — ");
            if (o.printType.equals("Gambar di HVS")) {
                msg.append("Gambar di HVS — ").append(o.paper)
                        .append(" — ").append(o.colorMode)
                        .append(" — ").append(o.layout)
                        .append(" — ").append(o.qty).append(" lembar");
            } else {
                msg.append(o.size).append(" — ").append(o.qty).append(" lembar — ")
                        .append(o.fit ? "sesuaikan/crop" : "tanpa crop");
                if (isPasFoto(o.size)) msg.append(" — latar: ").append(o.background);
            }
            msg.append("\n");
        }
        msg.append("\nTotal: ").append(total).append(" lembar");
        if (!customerNote.isEmpty()) msg.append("\n\nCatatan: ").append(customerNote);

        ArrayList<Uri> uris = new ArrayList<>();
        for (OrderItem o : items) uris.add(o.uri);
        Intent share = new Intent(Intent.ACTION_SEND_MULTIPLE);
        share.setType("image/*");
        share.putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris);
        share.putExtra(Intent.EXTRA_TEXT, msg.toString());
        share.putExtra("jid", PIXELSOFT_WA_NUMBER + "@s.whatsapp.net");
        share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        share.setPackage("com.whatsapp");
        try {
            startActivity(share);
        } catch (Exception e) {
            Toast.makeText(this, "WhatsApp belum terpasang atau tidak bisa dibuka.", Toast.LENGTH_LONG).show();
            Intent fallback = new Intent(Intent.ACTION_VIEW,
                    Uri.parse("https://wa.me/" + PIXELSOFT_WA_NUMBER + "?text=" + Uri.encode(msg.toString())));
            startActivity(fallback);
        }
    }
}
