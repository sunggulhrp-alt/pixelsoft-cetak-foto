package com.pixelsoft.cetakfoto;

import android.app.Activity;
import android.content.ClipData;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int PICK_IMAGES = 101;
    // GANTI dengan nomor WhatsApp PixelSoft, format internasional tanpa + atau spasi.
    private static final String PIXELSOFT_WA_NUMBER = "6282163917003";
    private final ArrayList<Uri> selectedUris = new ArrayList<>();
    private final ArrayList<OrderItem> items = new ArrayList<>();
    private LinearLayout root;
    private LinearLayout listContainer;
    private TextView countText;

    private final String[] sizes = {"Pas Foto 2×3", "Pas Foto 3×4", "Pas Foto 4×6", "Dompet", "3R (biasa)", "4R (Jumbo Kecil)", "5R (Jumbo Besar)", "8R (10 inch)", "Full A4"};

    static class OrderItem {
        Uri uri;
        String size = "Pas Foto 4×6";
        int qty = 1;
        boolean fit = true;
        String background = "Tidak diganti";
        OrderItem(Uri uri) { this.uri = uri; }
    }

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        showHome();
    }

    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + .5f); }
    private TextView text(String s, float sp) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(sp); t.setTextColor(Color.rgb(20,45,65));
        t.setPadding(dp(8), dp(6), dp(8), dp(6)); return t;
    }
    private Button button(String s) {
        Button b = new Button(this); b.setText(s); b.setTextSize(15); b.setAllCaps(false); return b;
    }

    private void base(String title) {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.WHITE);

        // Keep app content clear of the Android status/navigation bars.
        root.setOnApplyWindowInsetsListener((v, insets) -> {
            android.graphics.Insets bars = insets.getInsets(
                    WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars());
            v.setPadding(0, bars.top, 0, bars.bottom);
            return insets;
        });

        TextView bar = text("PIXELSOFT
" + title, 20);
        bar.setTextColor(Color.WHITE);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(20), dp(14), dp(20), dp(14));
        bar.setBackgroundColor(Color.rgb(12,145,181));
        root.addView(bar, new LinearLayout.LayoutParams(-1, dp(76)));

        setContentView(root);
        root.requestApplyInsets();
    }

    private void showHome() {
        base("Cetak Foto");
        LinearLayout box = new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setGravity(Gravity.CENTER_HORIZONTAL); box.setPadding(dp(24), dp(30), dp(24), dp(24));
        TextView title = text("Cetak foto jadi lebih mudah", 28); title.setGravity(Gravity.CENTER); title.setTextColor(Color.rgb(18,91,135)); box.addView(title);
        TextView sub = text("Pilih foto • tentukan ukuran • jumlah • kirim ke WhatsApp PixelSoft", 16); sub.setGravity(Gravity.CENTER); box.addView(sub);
        ImageView icon = new ImageView(this); icon.setImageResource(com.pixelsoft.cetakfoto.R.drawable.pixelsoft_icon); icon.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        box.addView(icon, new LinearLayout.LayoutParams(-1, dp(250)));
        Button pick = button("📷  PILIH FOTO DARI GALERI"); pick.setOnClickListener(v -> pickImages());
        box.addView(pick, new LinearLayout.LayoutParams(-1, dp(58)));
        root.addView(box, new LinearLayout.LayoutParams(-1, 0, 1));
        TextView foot = text("PixelSoft • Solusi Cetak & Layanan Digital", 13); foot.setGravity(Gravity.CENTER); root.addView(foot, new LinearLayout.LayoutParams(-1, dp(44)));
    }

    private void pickImages() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT); i.setType("image/*"); i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true); i.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(i, PICK_IMAGES);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != PICK_IMAGES || resultCode != RESULT_OK || data == null) return;
        selectedUris.clear();
        if (data.getClipData() != null) {
            int n = Math.min(data.getClipData().getItemCount(), 10);
            for (int x=0; x<n; x++) selectedUris.add(data.getClipData().getItemAt(x).getUri());
        } else if (data.getData() != null) selectedUris.add(data.getData());
        if (selectedUris.isEmpty()) return;
        items.clear(); for (Uri u : selectedUris) items.add(new OrderItem(u));
        showEditor();
    }

    private void showEditor() {
        base("Atur Pesanan");
        ScrollView scroll = new ScrollView(this); listContainer = new LinearLayout(this); listContainer.setOrientation(LinearLayout.VERTICAL); listContainer.setPadding(dp(12), dp(12), dp(12), dp(12));
        countText = text("Foto dipilih: " + items.size() + " / 10", 17); countText.setTextColor(Color.rgb(12,145,181)); listContainer.addView(countText);
        for (int i=0;i<items.size();i++) addItemView(i);
        Button add = button("+ Tambah Foto"); add.setOnClickListener(v -> pickImages()); listContainer.addView(add);
        Button next = button("LANJUT KE RINGKASAN →"); next.setOnClickListener(v -> showSummary()); listContainer.addView(next);
        scroll.addView(listContainer); root.addView(scroll, new LinearLayout.LayoutParams(-1,0,1));
    }

    private void addItemView(int index) {
        OrderItem item = items.get(index);
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(10), dp(10), dp(10), dp(10));

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        ImageView iv = new ImageView(this);
        iv.setImageURI(item.uri);
        iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
        top.addView(iv, new LinearLayout.LayoutParams(dp(110), dp(110)));
        TextView name = text("Foto " + (index + 1), 17);
        name.setTextColor(Color.rgb(20,45,65));
        top.addView(name, new LinearLayout.LayoutParams(0, -2, 1));
        card.addView(top);

        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        TextView sl = text("Ukuran", 14);
        row.addView(sl);
        Spinner sp = new Spinner(this);
        ArrayAdapter<String> ad = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, sizes);
        sp.setAdapter(ad);
        sp.setSelection(indexOf(sizes, item.size));
        sp.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            public void onNothingSelected(android.widget.AdapterView<?> p) {}
            public void onItemSelected(android.widget.AdapterView<?> p, View v, int pos, long id) {
                item.size = sizes[pos];
                updatePasFotoOptions(card, item);
            }
        });
        row.addView(sp, new LinearLayout.LayoutParams(dp(190), dp(50)));
        TextView ql = text("Jumlah", 14);
        row.addView(ql);
        EditText qty = new EditText(this);
        qty.setInputType(2);
        qty.setText(String.valueOf(item.qty));
        qty.setSelectAllOnFocus(true);
        qty.setOnFocusChangeListener((v, has) -> {
            if (!has) {
                try { item.qty = Math.max(1, Integer.parseInt(qty.getText().toString())); }
                catch (Exception e) { item.qty = 1; qty.setText("1"); }
            }
        });
        row.addView(qty, new LinearLayout.LayoutParams(dp(65), dp(50)));
        card.addView(row);

        CheckBox fit = new CheckBox(this);
        fit.setText("Sesuaikan foto dengan ukuran (crop bila perlu)");
        fit.setChecked(item.fit);
        fit.setOnCheckedChangeListener((b,c) -> item.fit = c);
        card.addView(fit);

        LinearLayout pasFotoOptions = new LinearLayout(this);
        pasFotoOptions.setOrientation(LinearLayout.VERTICAL);
        pasFotoOptions.setTag("pasFotoOptions");
        card.addView(pasFotoOptions);
        updatePasFotoOptions(card, item);

        TextView divider = text("────────────────────────────────", 10);
        divider.setTextColor(Color.LTGRAY);
        card.addView(divider);
        listContainer.addView(card);
    }

    private boolean isPasFoto(String size) {
        return size.startsWith("Pas Foto");
    }

    private void updatePasFotoOptions(LinearLayout card, OrderItem item) {
        View v = card.findViewWithTag("pasFotoOptions");
        if (!(v instanceof LinearLayout)) return;
        LinearLayout box = (LinearLayout) v;
        box.removeAllViews();
        if (!isPasFoto(item.size)) return;

        TextView label = text("Pengaturan Pas Foto", 15);
        label.setTextColor(Color.rgb(12,145,181));
        box.addView(label);

        CheckBox replace = new CheckBox(this);
        replace.setText("Ganti latar foto");
        replace.setChecked(!item.background.equals("Tidak diganti"));
        box.addView(replace);

        Spinner bg = new Spinner(this);
        String[] backgrounds = {"Tidak diganti", "Merah", "Biru"};
        ArrayAdapter<String> bgAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, backgrounds);
        bg.setAdapter(bgAdapter);
        bg.setSelection(indexOf(backgrounds, item.background));
        bg.setEnabled(replace.isChecked());
        bg.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            public void onNothingSelected(android.widget.AdapterView<?> p) {}
            public void onItemSelected(android.widget.AdapterView<?> p, View v, int pos, long id) { item.background = backgrounds[pos]; }
        });
        replace.setOnCheckedChangeListener((b, checked) -> {
            bg.setEnabled(checked);
            if (!checked) { item.background = "Tidak diganti"; bg.setSelection(0); }
            else if (item.background.equals("Tidak diganti")) { item.background = "Merah"; bg.setSelection(1); }
        });
        box.addView(bg, new LinearLayout.LayoutParams(dp(150), dp(50)));
    }

    private int indexOf(String[] a,String s){for(int i=0;i<a.length;i++)if(a[i].equals(s))return i;return 0;}

    private void showSummary() {
        for (OrderItem item:items) if(item.qty<1)item.qty=1;
        base("Ringkasan Pesanan");
        ScrollView scroll=new ScrollView(this); LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(18),dp(18),dp(18),dp(18));
        box.addView(text("Pesanan Anda",24)); int total=0;
        for(int i=0;i<items.size();i++){OrderItem o=items.get(i); total+=o.qty; TextView t=text("Foto "+(i+1)+"  •  "+o.size+"  •  "+o.qty+" lembar  •  "+(o.fit?"crop":"utuh") + (isPasFoto(o.size) ? " • latar: " + o.background : ""),17); box.addView(t);}
        box.addView(text("\nTOTAL: "+total+" LEMBAR",22));
        Button edit=button("← KEMBALI ATUR PESANAN"); edit.setOnClickListener(v->showEditor()); box.addView(edit);
        Button send=button("📲  KIRIM KE WHATSAPP PIXELSOFT\n082163917003"); send.setOnClickListener(v->sendToWhatsApp()); box.addView(send);
        TextView note=text("WhatsApp PixelSoft: 082163917003\nFoto akan dilampirkan ke WhatsApp bersama detail pesanan.",14); note.setPadding(8,20,8,8); box.addView(note);
        scroll.addView(box); root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
    }

    private void sendToWhatsApp() {
        StringBuilder msg=new StringBuilder("Halo PixelSoft, saya ingin cetak foto.\n\nNomor WhatsApp PixelSoft: 082163917003\n\n"); int total=0;
        for(int i=0;i<items.size();i++){OrderItem o=items.get(i);total+=o.qty;msg.append(i+1).append(". Foto ").append(i+1).append(" — ").append(o.size).append(" — ").append(o.qty).append(" lembar — ").append(o.fit?"sesuaikan/crop":"tanpa crop");
            if (isPasFoto(o.size)) msg.append(" — latar: ").append(o.background);
            msg.append("\n");}
        msg.append("\nTotal: ").append(total).append(" lembar");
        ArrayList<Uri> uris=new ArrayList<>(); for(OrderItem o:items) uris.add(o.uri);
        Intent share=new Intent(Intent.ACTION_SEND_MULTIPLE); share.setType("image/*"); share.putParcelableArrayListExtra(Intent.EXTRA_STREAM,uris); share.putExtra(Intent.EXTRA_TEXT,msg.toString()); share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION); share.setPackage("com.whatsapp");
        try { startActivity(share); } catch(Exception e) {
            Toast.makeText(this,"WhatsApp belum terpasang atau tidak bisa dibuka. Detail pesanan sudah disiapkan.",Toast.LENGTH_LONG).show();
            Intent fallback=new Intent(Intent.ACTION_SENDTO,Uri.parse("https://wa.me/"+PIXELSOFT_WA_NUMBER)); fallback.putExtra(Intent.EXTRA_TEXT,msg.toString()); startActivity(fallback);
        }
    }
}
