# PixelSoft Cetak Foto v1.1

Aplikasi pemesanan cetak foto PixelSoft.

## WhatsApp PixelSoft
082163917003

## Ukuran Cetak
- Pas Foto 2×3
- Pas Foto 3×4
- Pas Foto 4×6
- Dompet
- 3R (biasa)
- 4R (Jumbo Kecil)
- 5R (Jumbo Besar)
- 8R (10 inch)
- Full A4

Untuk ukuran Pas Foto, tersedia pilihan **Ganti latar**: Tidak diganti, Merah, atau Biru.
