package com.pixelsoft.cetakfoto;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

public class PixelSoftFileProvider extends ContentProvider {
    public static Uri getUriForFile(android.content.Context context, File file) {
        return Uri.parse("content://" + context.getPackageName() + ".fileprovider/file/" +
                Uri.encode(file.getAbsolutePath()));
    }
    @Override public boolean onCreate(){ return true; }
    private File resolve(Uri uri) throws FileNotFoundException {
        String encoded=uri.getEncodedPath();
        if(encoded==null || !encoded.startsWith("/file/")) throw new FileNotFoundException();
        String path=Uri.decode(encoded.substring(6));
        File f=new File(path);
        File root=getContext().getExternalFilesDir("Documents");
        try { if(!f.getCanonicalPath().startsWith(root.getCanonicalPath()+File.separator)) throw new FileNotFoundException(); }
        catch(IOException e){ throw new FileNotFoundException(); }
        if(!f.isFile()) throw new FileNotFoundException();
        return f;
    }
    @Override public String getType(Uri uri){
        String p=uri.getLastPathSegment();
        if(p!=null && p.toLowerCase().endsWith(".docx")) return "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
        return "application/octet-stream";
    }
    @Override public ParcelFileDescriptor openFile(Uri uri,String mode) throws FileNotFoundException { return ParcelFileDescriptor.open(resolve(uri),ParcelFileDescriptor.MODE_READ_ONLY); }
    @Override public Cursor query(Uri uri,String[] projection,String selection,String[] selectionArgs,String sortOrder){
        try { File f=resolve(uri); String[] cols=projection!=null?projection:new String[]{"_display_name","_size"}; MatrixCursor c=new MatrixCursor(cols,1); Object[] row=new Object[cols.length]; for(int i=0;i<cols.length;i++){ if("_display_name".equals(cols[i])) row[i]=f.getName(); else if("_size".equals(cols[i])) row[i]=f.length(); } c.addRow(row); return c; } catch(Exception e){ return null; }
    }
    @Override public int delete(Uri uri,String selection,String[] selectionArgs){ try{return resolve(uri).delete()?1:0;}catch(Exception e){return 0;} }
    @Override public int update(Uri uri,ContentValues values,String selection,String[] selectionArgs){ return 0; }
    @Override public Uri insert(Uri uri,ContentValues values){ return null; }
}
