# PixelSoft Cetak Foto v1.11.0

Penambahan fitur **Susun Foto ke Media Cetak**.

- Terintegrasi ke layanan Cetak Foto & Gambar.
- Pelanggan dapat memilih ukuran 2×3 cm, 3×4 cm, atau 4×6 cm.
- Foto dapat digeser pada media layout.
- Foto yang sama boleh ditambahkan berkali-kali, termasuk dengan ukuran berbeda.
- Hasil akhir dibuat sebagai satu JPG 1200×1800 px (media layout internal 4×6 inch pada 300 dpi).
- File dikirim langsung ke WhatsApp PixelSoft menggunakan target JID yang sama dengan modul sebelumnya.
- Tidak ada editing/background replacement pada fitur ini; foto ditempatkan apa adanya dengan proporsi dipertahankan.


Version 1.12.2:
- Editor media cetak memiliki mode fokus layar penuh agar lembar kerja otomatis membesar.
- Tombol ⛶ digunakan untuk masuk mode fokus; tombol Back Android mengembalikan kontrol.
- File JPG layout tetap 1200×1800 piksel, setara 4×6 inci pada 300 DPI, dan metadata resolusi 300 DPI disimpan pada JPEG.


Version 1.12.6:
- Ukuran foto aktual tetap 2×3 = 2,15×2,8 cm; 3×4 = 2,85×3,75 cm; 4×6 = 3,8×5,7 cm.
- Ditambahkan area putih total 3 mm pada setiap pasfoto, yaitu 1,5 mm di setiap sisi.
- Area putih menjadi bagian dari bidang foto yang dapat diposisikan dan dibatasi di dalam media.
- Foto aktual tetap berada di tengah area putih dan hasil ekspor mempertahankan ruang potong tersebut.
- Rotasi 90° memutar seluruh bidang pasfoto beserta area putihnya.
