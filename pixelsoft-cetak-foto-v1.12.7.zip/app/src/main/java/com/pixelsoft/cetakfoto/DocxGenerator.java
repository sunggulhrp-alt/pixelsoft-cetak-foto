package com.pixelsoft.cetakfoto;

import android.content.Context;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

public final class DocxGenerator {
    private DocxGenerator() {}

    public static File createSuratJualBeli(Context context, Map<String, String> data) throws IOException {
        File dir = new File(context.getExternalFilesDir("Documents"), "PixelSoft");
        if (!dir.exists() && !dir.mkdirs()) throw new IOException("Tidak dapat membuat folder dokumen");
        String safe = data.get("NAMA_PENJUAL");
        if (safe == null || safe.trim().isEmpty()) safe = "Pelanggan";
        safe = safe.replaceAll("[^A-Za-z0-9._-]", "_");
        File out = new File(dir, "Surat_Jual_Beli_" + safe + ".docx");

        try (ZipOutputStream zip = new ZipOutputStream(new FileOutputStream(out))) {
            put(zip, "[Content_Types].xml", contentTypes());
            put(zip, "_rels/.rels", rootRels());
            put(zip, "word/document.xml", documentXml(data));
            put(zip, "word/styles.xml", stylesXml());
            put(zip, "word/settings.xml", settingsXml());
            put(zip, "word/_rels/document.xml.rels", documentRels());
        }
        return out;
    }

    private static void put(ZipOutputStream zip, String name, String text) throws IOException {
        zip.putNextEntry(new ZipEntry(name));
        zip.write(text.getBytes(StandardCharsets.UTF_8));
        zip.closeEntry();
    }

    private static String esc(String s) {
        if (s == null) return "";
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
                .replace("\"", "&quot;").replace("'", "&apos;");
    }

    private static String val(Map<String,String> d, String key) { return esc(d.get(key)); }

    private static String p(String text) {
        return "<w:p><w:pPr><w:spacing w:line=\"240\" w:lineRule=\"auto\" w:before=\"0\" w:after=\"0\"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii=\"Times New Roman\" w:hAnsi=\"Times New Roman\" w:eastAsia=\"Times New Roman\"/><w:sz w:val=\"24\"/><w:szCs w:val=\"24\"/></w:rPr><w:t xml:space=\"preserve\">" + esc(text) + "</w:t></w:r></w:p>";
    }

    private static String boldP(String text) {
        return "<w:p><w:pPr><w:jc w:val=\"center\"/><w:spacing w:line=\"240\" w:before=\"0\" w:after=\"160\"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii=\"Times New Roman\" w:hAnsi=\"Times New Roman\" w:eastAsia=\"Times New Roman\"/><w:b/><w:u w:val=\"single\"/><w:sz w:val=\"24\"/><w:szCs w:val=\"24\"/></w:rPr><w:t>" + esc(text) + "</w:t></w:r></w:p>";
    }

    private static String documentXml(Map<String,String> d) {
        StringBuilder x = new StringBuilder();
        x.append("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><w:document xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\"><w:body>");
        x.append("<w:sectPr><w:pgSz w:w=\"12240\" w:h=\"18720\"/><w:pgMar w:top=\"936\" w:right=\"1080\" w:bottom=\"936\" w:left=\"1080\" w:header=\"0\" w:footer=\"0\" w:gutter=\"0\"/></w:sectPr>");
        // sectPr must be the final body child, so build content first in a second buffer.
        StringBuilder b = new StringBuilder();
        b.append(boldP("SURAT JUAL BELI"));
        b.append(p("Yang bertanda tangan dibawah ini:"));
        b.append(p("Nama                 : " + val(d,"NAMA_PENJUAL")));
        b.append(p("Tempat/Tgl. lahir    : " + val(d,"TTL_PENJUAL")));
        b.append(p("Agama                : " + val(d,"AGAMA_PENJUAL")));
        b.append(p("Pekerjaan            : " + val(d,"PEKERJAAN_PENJUAL")));
        b.append(p("Alamat               : " + val(d,"ALAMAT_PENJUAL")));
        b.append(p("Disebut sebagai Pihak Pertama (Penjual)"));
        b.append(p("Nama                 : " + val(d,"NAMA_PEMBELI")));
        b.append(p("Tempat/Tgl. lahir    : " + val(d,"TTL_PEMBELI")));
        b.append(p("Agama                : " + val(d,"AGAMA_PEMBELI")));
        b.append(p("Pekerjaan            : " + val(d,"PEKERJAAN_PEMBELI")));
        b.append(p("Alamat               : " + val(d,"ALAMAT_PEMBELI")));
        b.append(p("Disebut sebagai Pihak Kedua (Pembeli)"));
        String lokasi = d.get("LOKASI_TANAH");
        String lokasiText = (lokasi == null || lokasi.trim().isEmpty()) ? "" : " yang terletak di " + val(d,"LOKASI_TANAH");
        b.append(p("Saya PIHAK I (Pertama) menyatakan dengan sesungguhnya telah menjual Sebidang Tanah milik saya sendiri kepada Pihak II (Kedua) dengan Ukuran " + val(d,"LUAS_TANAH") + lokasiText + ", " + val(d,"DESA_TANAH") + ", " + val(d,"KECAMATAN_TANAH") + ", " + val(d,"KABUPATEN_TANAH") + ", dengan harga Rp. " + val(d,"HARGA_NUMERIK") + " (" + val(d,"HARGA_TERBILANG") + ")."));
        b.append(p("Adapun batas-batas Tanah tersebut adalah sebagai berikut :"));
        b.append(p("-     Sebelah Timur Berbatasan Dengan " + val(d,"BATAS_TIMUR")));
        b.append(p("-     Sebelah Barat Berbatasan Dengan " + val(d,"BATAS_BARAT")));
        b.append(p("-     Sebelah Utara Berbatasan Dengan " + val(d,"BATAS_UTARA")));
        b.append(p("-     Sebelah Selatan Berbatasan Dengan " + val(d,"BATAS_SELATAN")));
        b.append(p("Setelah ditanda tanganinya Surat Jual Beli ini, maka gugurlah hak milik Saya, Pihak Pertama atas Tanah tersebut dan menjadi hak milik Pihak Kedua, dan Dengan ini Saya, Pihak Pertama menerangkan bahwa Tanah tersebut tidak sedang dalam sengketa ataupun tidak sedang diagunkan ke pihak lain."));
        b.append(p("Demikianlah Surat Jual Beli Tanah ini kami perbuat dengan sebenarnya oleh Pihak I (pertama) dan Pihak II (kedua) dengan akal dan pikiran yang sehat (Waras) dan tidak ada paksaan dari pihak manapun, dihadapan para saksi yang ikut bertanda tangan di bawah ini."));
        b.append(p("Pihak Ke II / Pembeli                              " + val(d,"TEMPAT_SURAT") + ", " + val(d,"TANGGAL_SURAT")));
        b.append(p("\n\n(" + val(d,"NAMA_PEMBELI") + ")"));
        b.append(p("Pihak ke I / Penjual"));
        b.append(p("\n\n(" + val(d,"NAMA_PENJUAL") + ")"));
        b.append(p("Saksi-saksi:"));
        b.append(p("1.  " + val(d,"NAMA_SAKSI_1") + "     (                    )"));
        b.append(p("2.  " + val(d,"NAMA_SAKSI_2") + "     (                    )"));
        b.append(p("Mengetahui ;"));
        b.append(p("Kepala Desa " + val(d,"NAMA_DESA")));
        b.append(p("\n\n(" + val(d,"NAMA_KEPALA_DESA") + ")"));
        x.setLength(0);
        x.append("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><w:document xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\"><w:body>");
        x.append(b);
        x.append("<w:sectPr><w:pgSz w:w=\"12240\" w:h=\"18720\"/><w:pgMar w:top=\"936\" w:right=\"1080\" w:bottom=\"936\" w:left=\"1080\" w:header=\"0\" w:footer=\"0\" w:gutter=\"0\"/></w:sectPr></w:body></w:document>");
        return x.toString();
    }

    private static String contentTypes() {
        return "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\"><Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/><Default Extension=\"xml\" ContentType=\"application/xml\"/><Override PartName=\"/word/document.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml\"/><Override PartName=\"/word/styles.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml\"/><Override PartName=\"/word/settings.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.wordprocessingml.settings+xml\"/></Types>";
    }
    private static String rootRels() {
        return "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"word/document.xml\"/></Relationships>";
    }
    private static String documentRels() {
        return "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles\" Target=\"styles.xml\"/><Relationship Id=\"rId2\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/settings\" Target=\"settings.xml\"/></Relationships>";
    }
    private static String stylesXml() {
        return "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><w:styles xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\"><w:docDefaults><w:rPrDefault><w:rPr><w:rFonts w:ascii=\"Times New Roman\" w:hAnsi=\"Times New Roman\" w:eastAsia=\"Times New Roman\"/><w:sz w:val=\"24\"/><w:szCs w:val=\"24\"/></w:rPr></w:rPrDefault><w:pPrDefault><w:pPr><w:spacing w:line=\"240\" w:after=\"0\" w:before=\"0\"/></w:pPr></w:pPrDefault></w:docDefaults><w:style w:type=\"paragraph\" w:default=\"1\" w:styleId=\"Normal\"><w:name w:val=\"Normal\"/></w:style></w:styles>";
    }
    private static String settingsXml() {
        return "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><w:settings xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\"><w:zoom w:percent=\"100\"/></w:settings>";
    }
}
